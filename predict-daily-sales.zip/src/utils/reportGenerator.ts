import jsPDF from 'jspdf';
import {
  DatasetStatistics,
  TrainedModelSystem,
  PredictionResult,
  ForecastDayResult,
  CleanSalesRecord,
} from '../types';
import { generateDynamicInsights } from './insights';
import { computeCategoryAnalysis, computePromotionAnalysis } from './salesAnalysis';
import { formatCurrency, formatNumber } from './predictionUtils';

export interface GenerateReportParams {
  stats: DatasetStatistics;
  modelSystem: TrainedModelSystem;
  records: CleanSalesRecord[];
  activePrediction?: PredictionResult | null;
  activeForecast?: ForecastDayResult[] | null;
}

export async function generatePdfReport({
  stats,
  modelSystem,
  records,
  activePrediction,
  activeForecast,
}: GenerateReportParams): Promise<void> {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 18;
    let y = margin;

    const checkPageBreak = (neededHeight: number) => {
      if (y + neededHeight > pageHeight - margin) {
        doc.addPage();
        y = margin;
        renderHeader();
      }
    };

    const renderHeader = () => {
      doc.setFontSize(8);
      doc.setTextColor(120, 120, 120);
      doc.text('PREDICT DAILY SALES  |  EXECUTIVE ML ANALYTICS REPORT', margin, 12);
      doc.setDrawColor(220, 225, 230);
      doc.line(margin, 14, pageWidth - margin, 14);
    };

    // ==========================================
    // COVER / TITLE BLOCK
    // ==========================================
    renderHeader();
    y = 24;

    doc.setFillColor(30, 41, 59); // Slate 800
    doc.roundedRect(margin, y, pageWidth - margin * 2, 34, 3, 3, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(255, 255, 255);
    doc.text('Predict Daily Sales', margin + 8, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(203, 213, 225); // Slate 300
    doc.text('Machine Learning Sales Forecasting & Historical Trend Report', margin + 8, y + 20);

    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // Slate 400
    const nowStr = new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    doc.text(`Generated on: ${nowStr}  |  Browser-Engineered ML Pipeline`, margin + 8, y + 27);

    y += 42;

    // ==========================================
    // SECTION 1: DATASET SUMMARY
    // ==========================================
    checkPageBreak(45);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('1. Historical Dataset Summary', margin, y);
    y += 6;

    doc.setDrawColor(226, 232, 240);
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(margin, y, pageWidth - margin * 2, 32, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);

    const col1X = margin + 6;
    const col2X = margin + 60;
    const col3X = margin + 118;

    doc.text(`Total Records: ${formatNumber(stats.totalRecords)} days`, col1X, y + 8);
    doc.text(`Total Revenue: ${formatCurrency(stats.totalSales)}`, col1X, y + 15);
    doc.text(`Date Range: ${stats.dateRange.start} to ${stats.dateRange.end}`, col1X, y + 22);

    doc.text(`Average Daily Sales: ${formatCurrency(stats.averageDailySales)}`, col2X, y + 8);
    doc.text(`Highest Daily Sales: ${formatCurrency(stats.highestDailySales)}`, col2X, y + 15);
    doc.text(`Lowest Daily Sales: ${formatCurrency(stats.lowestDailySales)}`, col2X, y + 22);

    doc.text(`Average Quantity Sold: ${formatNumber(stats.averageQuantity)} units`, col3X, y + 8);
    doc.text(`Average Product Price: ${formatCurrency(stats.averagePrice)}`, col3X, y + 15);
    doc.text(`Promotional Days: ${stats.promotionDays} (${stats.promotionPercent}%)`, col3X, y + 22);

    y += 40;

    // ==========================================
    // SECTION 2: MODEL PERFORMANCE BENCHMARK
    // ==========================================
    checkPageBreak(65);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('2. Machine Learning Model Performance (Chronological Test Evaluation)', margin, y);
    y += 6;

    // Table Header
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);

    doc.text('Model Architecture', margin + 4, y + 5);
    doc.text('MAE (Error)', margin + 60, y + 5);
    doc.text('MSE', margin + 95, y + 5);
    doc.text('RMSE', margin + 125, y + 5);
    doc.text('R² Score', margin + 148, y + 5);
    doc.text('Status', margin + 168, y + 5);
    y += 7;

    const lr = modelSystem.linearRegression;
    const rf = modelSystem.randomForest;
    const bestType = modelSystem.bestModelType;

    // Row 1: Linear Regression
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(30, 41, 59);
    doc.rect(margin, y, pageWidth - margin * 2, 7);
    doc.text('Linear Regression (OLS + Ridge)', margin + 4, y + 5);
    doc.text(formatCurrency(lr.mae), margin + 60, y + 5);
    doc.text(formatNumber(lr.mse), margin + 95, y + 5);
    doc.text(formatCurrency(lr.rmse), margin + 125, y + 5);
    doc.text(lr.r2.toString(), margin + 148, y + 5);
    doc.text(bestType === 'linearRegression' ? 'Selected Best' : 'Baseline', margin + 168, y + 5);
    y += 7;

    // Row 2: Random Forest
    doc.rect(margin, y, pageWidth - margin * 2, 7);
    doc.text('Random Forest Regression (Ensemble)', margin + 4, y + 5);
    doc.text(formatCurrency(rf.mae), margin + 60, y + 5);
    doc.text(formatNumber(rf.mse), margin + 95, y + 5);
    doc.text(formatCurrency(rf.rmse), margin + 125, y + 5);
    doc.text(rf.r2.toString(), margin + 148, y + 5);
    doc.text(bestType === 'randomForest' ? 'Selected Best' : 'Comparison', margin + 168, y + 5);
    y += 12;

    // Feature Importance top 5
    const activeModel = bestType === 'randomForest' ? rf : lr;
    if (activeModel.featureImportance && activeModel.featureImportance.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(51, 65, 85);
      doc.text(`Top 5 Most Influential Factors (${activeModel.name}):`, margin, y);
      y += 5;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      const top5 = activeModel.featureImportance.slice(0, 5);
      const top5Str = top5.map((f, i) => `${i + 1}. ${f.feature} (${f.normalizedImportance}%)`).join('   |   ');
      doc.text(top5Str, margin, y);
      y += 10;
    }

    // ==========================================
    // SECTION 3: RECENT PREDICTION & ESTIMATE
    // ==========================================
    if (activePrediction) {
      checkPageBreak(50);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text('3. Daily Sales Prediction Result', margin, y);
      y += 6;

      doc.setFillColor(240, 253, 244); // Light green
      doc.setDrawColor(187, 247, 208);
      doc.roundedRect(margin, y, pageWidth - margin * 2, 28, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(22, 101, 52); // Green 800
      doc.text(`Expected Predicted Sales: ${formatCurrency(activePrediction.predictedSales)}`, margin + 6, y + 9);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(21, 128, 61);
      doc.text(
        `Confidence Range: ${formatCurrency(activePrediction.lowerEstimate)} – ${formatCurrency(activePrediction.upperEstimate)} (±${formatCurrency(activePrediction.margin)})`,
        margin + 6,
        y + 16
      );

      doc.setTextColor(51, 65, 85);
      doc.text(
        `Target Date: ${activePrediction.predictionDate}  |  Category: ${activePrediction.input.product_category}  |  Model: ${activePrediction.modelUsed}`,
        margin + 6,
        y + 23
      );

      y += 34;
    }

    // ==========================================
    // SECTION 4: MULTI-DAY FORECAST SCHEDULE
    // ==========================================
    if (activeForecast && activeForecast.length > 0) {
      checkPageBreak(40 + Math.min(7, activeForecast.length) * 6);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text(`4. Multi-Day Sales Forecast (${activeForecast.length} Days)`, margin, y);
      y += 6;

      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);

      doc.text('Date', margin + 4, y + 4.5);
      doc.text('Day of Week', margin + 35, y + 4.5);
      doc.text('Predicted Sales', margin + 70, y + 4.5);
      doc.text('Lower Bound', margin + 110, y + 4.5);
      doc.text('Upper Bound', margin + 145, y + 4.5);
      y += 6;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(30, 41, 59);

      const displayList = activeForecast.slice(0, 14); // show up to 14 days
      for (const f of displayList) {
        doc.rect(margin, y, pageWidth - margin * 2, 5.5);
        doc.text(f.date, margin + 4, y + 4);
        doc.text(f.dayOfWeek + (f.isWeekend ? ' (Weekend)' : ''), margin + 35, y + 4);
        doc.text(formatCurrency(f.predictedSales), margin + 70, y + 4);
        doc.text(formatCurrency(f.lowerEstimate), margin + 110, y + 4);
        doc.text(formatCurrency(f.upperEstimate), margin + 145, y + 4);
        y += 5.5;
      }
      y += 8;
    }

    // ==========================================
    // SECTION 5: DYNAMIC BUSINESS INSIGHTS
    // ==========================================
    checkPageBreak(50);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('5. Machine-Generated Business Insights', margin, y);
    y += 6;

    const dynamicInsights = generateDynamicInsights(stats, modelSystem, records);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);

    for (const insight of dynamicInsights.slice(0, 5)) {
      checkPageBreak(12);
      doc.setFont('helvetica', 'bold');
      doc.text(`• ${insight.title}:`, margin, y);
      const titleWidth = doc.getTextWidth(`• ${insight.title}: `);
      doc.setFont('helvetica', 'normal');

      const splitText = doc.splitTextToSize(insight.description, pageWidth - margin * 2 - titleWidth);
      doc.text(splitText[0], margin + titleWidth, y);
      y += 5;

      if (splitText.length > 1) {
        for (let s = 1; s < splitText.length; s++) {
          doc.text(splitText[s], margin + 6, y);
          y += 4.5;
        }
      }
      y += 2;
    }

    // ==========================================
    // DISCLAIMER FOOTER
    // ==========================================
    checkPageBreak(25);
    y += 6;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 4;

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 140, 140);
    const disclaimerText =
      'Disclaimer: Sales predictions are estimates generated from historical data patterns and available business factors. Actual future sales may differ due to changing market conditions, consumer behavior, competitor pricing, and unanticipated externalities. Predictions should be considered statistical guidance rather than guaranteed business outcomes.';
    const splitDisclaimer = doc.splitTextToSize(disclaimerText, pageWidth - margin * 2);
    doc.text(splitDisclaimer, margin, y);

    // Save File
    doc.save('daily-sales-prediction-report.pdf');
  } catch (err) {
    console.error('Failed to generate PDF report:', err);
    throw new Error('Unable to generate the report. Please try again.');
  }
}
