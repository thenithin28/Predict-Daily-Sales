import { PredictionPoint } from '../types';

export interface CalculatedMetrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
  meanResidual: number;
  maxPositiveResidual: number;
  maxNegativeResidual: number;
  predictions: PredictionPoint[];
}

export function evaluatePredictions(
  actuals: number[],
  predicted: number[],
  dates: string[]
): CalculatedMetrics {
  const n = actuals.length;
  if (n === 0) {
    return {
      mae: 0,
      mse: 0,
      rmse: 0,
      r2: 0,
      meanResidual: 0,
      maxPositiveResidual: 0,
      maxNegativeResidual: 0,
      predictions: [],
    };
  }

  let absErrorSum = 0;
  let sqErrorSum = 0;
  let residualSum = 0;
  let actualSum = 0;

  let maxPos = -Infinity;
  let maxNeg = Infinity;

  const points: PredictionPoint[] = [];

  for (let i = 0; i < n; i++) {
    const act = actuals[i];
    const pred = predicted[i];
    const residual = act - pred;
    const absErr = Math.abs(residual);
    const sqErr = residual * residual;

    absErrorSum += absErr;
    sqErrorSum += sqErr;
    residualSum += residual;
    actualSum += act;

    if (residual > maxPos) maxPos = residual;
    if (residual < maxNeg) maxNeg = residual;

    points.push({
      index: i,
      date: dates[i] || `Day ${i + 1}`,
      actual: Math.round(act),
      predicted: Math.round(pred),
      residual: Math.round(residual),
    });
  }

  const actualMean = actualSum / n;
  let totalSumSquares = 0;
  for (let i = 0; i < n; i++) {
    const diff = actuals[i] - actualMean;
    totalSumSquares += diff * diff;
  }

  const mae = absErrorSum / n;
  const mse = sqErrorSum / n;
  const rmse = Math.sqrt(mse);
  const r2 = totalSumSquares > 0 ? Math.max(-1, Math.min(1, 1 - sqErrorSum / totalSumSquares)) : 0;

  return {
    mae: Number(mae.toFixed(2)),
    mse: Number(mse.toFixed(2)),
    rmse: Number(rmse.toFixed(2)),
    r2: Number(r2.toFixed(4)),
    meanResidual: Number((residualSum / n).toFixed(2)),
    maxPositiveResidual: Number((maxPos === -Infinity ? 0 : maxPos).toFixed(2)),
    maxNegativeResidual: Number((maxNeg === Infinity ? 0 : maxNeg).toFixed(2)),
    predictions: points,
  };
}
