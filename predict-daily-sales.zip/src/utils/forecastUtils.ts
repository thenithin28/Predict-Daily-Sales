import { ForecastDayResult, PredictionInput, TrainedModelSystem } from '../types';

export function generateMultiDayForecast(
  baseInput: PredictionInput,
  daysCount: number,
  modelSystem: TrainedModelSystem,
  modelChoice?: 'linearRegression' | 'randomForest'
): ForecastDayResult[] {
  const results: ForecastDayResult[] = [];
  const chosenType = modelChoice || modelSystem.bestModelType;

  const startDate = new Date(baseInput.date);
  let runningPreviousSales = baseInput.previous_sales;

  for (let step = 1; step <= daysCount; step++) {
    const currentTargetDate = new Date(startDate);
    currentTargetDate.setDate(startDate.getDate() + (step - 1));

    const dateStr = currentTargetDate.toISOString().split('T')[0];
    const dayOfWeekIdx = currentTargetDate.getDay();
    const isWeekend = dayOfWeekIdx === 0 || dayOfWeekIdx === 6;
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Determine season for target date
    const month = currentTargetDate.getMonth() + 1;
    let season = 'Regular';
    if (month === 12 || month <= 2) season = 'Winter';
    else if (month >= 3 && month <= 5) season = 'Spring';
    else if (month >= 6 && month <= 8) season = 'Summer';
    else season = 'Fall';

    // Weekend promo boost tendency
    const isPromo = step === 1 ? baseInput.promotion : (isWeekend ? true : false);
    const isHoliday = step === 1 ? baseInput.holiday : false;

    // Adjust expected quantity & customers for weekend vs weekday
    const qtyMultiplier = isWeekend ? 1.25 : 1.0;
    const stepQuantity = Math.round(baseInput.quantity * qtyMultiplier);
    const stepCustomers = Math.round(baseInput.customers * qtyMultiplier);

    const stepInput: PredictionInput = {
      date: dateStr,
      product_category: baseInput.product_category,
      quantity: stepQuantity,
      price: baseInput.price,
      previous_sales: runningPreviousSales,
      customers: stepCustomers,
      promotion: isPromo,
      holiday: isHoliday,
      season,
    };

    const pred = modelSystem.predict(stepInput, chosenType);

    results.push({
      step,
      date: dateStr,
      predictedSales: pred.predictedSales,
      lowerEstimate: pred.lowerEstimate,
      upperEstimate: pred.upperEstimate,
      dayOfWeek: dayNames[dayOfWeekIdx],
      isWeekend,
      product_category: baseInput.product_category,
      season,
      promotion: isPromo,
      holiday: isHoliday,
    });

    // Feed recursive prediction into next day's previous_sales
    runningPreviousSales = pred.predictedSales;
  }

  return results;
}
