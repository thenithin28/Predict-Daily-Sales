import { PredictionInput, PredictionResult, TrainedModelSystem } from '../types';

export function runPrediction(
  input: PredictionInput,
  modelSystem: TrainedModelSystem,
  modelChoice?: 'linearRegression' | 'randomForest'
): PredictionResult {
  const chosenType = modelChoice || modelSystem.bestModelType;
  const rawResult = modelSystem.predict(input, chosenType);

  const histAvg = modelSystem.historicalAverageDailySales;
  const diffPercent = Number((((rawResult.predictedSales - histAvg) / histAvg) * 100).toFixed(1));

  let interpretation: 'above' | 'around' | 'below' = 'around';
  if (diffPercent > 5) {
    interpretation = 'above';
  } else if (diffPercent < -5) {
    interpretation = 'below';
  }

  return {
    predictedSales: rawResult.predictedSales,
    lowerEstimate: rawResult.lowerEstimate,
    upperEstimate: rawResult.upperEstimate,
    margin: rawResult.margin,
    predictionDate: input.date,
    modelUsed: rawResult.modelUsed,
    modelType: chosenType,
    interpretation,
    historicalAverage: histAvg,
    diffPercent,
    input,
  };
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(num));
}
