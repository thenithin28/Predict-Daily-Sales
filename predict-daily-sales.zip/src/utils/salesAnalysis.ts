import { CleanSalesRecord } from '../types';

export interface DailyTrendPoint {
  date: string;
  sales: number;
  movingAverage7d?: number;
  category: string;
}

export interface MonthlyTrendPoint {
  monthKey: string;
  monthLabel: string;
  totalSales: number;
  averageDailySales: number;
  recordCount: number;
  momGrowthPercent: number | null;
}

export interface CategorySummary {
  category: string;
  totalSales: number;
  averageSales: number;
  averageQuantity: number;
  averagePrice: number;
  recordCount: number;
  salesSharePercent: number;
}

export interface BinaryComparison {
  flag: string;
  count: number;
  totalSales: number;
  averageSales: number;
  averageQuantity: number;
  averagePrice: number;
}

export interface SeasonSummary {
  season: string;
  totalSales: number;
  averageSales: number;
  averageQuantity: number;
  recordCount: number;
}

export interface WeekdaySummary {
  dayName: string;
  dayIndex: number;
  averageSales: number;
  totalSales: number;
  averageQuantity: number;
  recordCount: number;
}

export interface CustomerSalesPoint {
  customers: number;
  sales: number;
  category: string;
  date: string;
}

export interface PriceSalesPoint {
  price: number;
  sales: number;
  quantity: number;
  category: string;
}

export interface QuantitySalesPoint {
  quantity: number;
  sales: number;
  price: number;
  category: string;
}

export function computeDailySalesTrend(
  records: CleanSalesRecord[],
  range: '7d' | '30d' | '90d' | '1y' | 'all' = 'all'
): DailyTrendPoint[] {
  let filtered = records;
  if (range === '7d') filtered = records.slice(-7);
  else if (range === '30d') filtered = records.slice(-30);
  else if (range === '90d') filtered = records.slice(-90);
  else if (range === '1y') filtered = records.slice(-365);

  const result: DailyTrendPoint[] = [];

  for (let i = 0; i < filtered.length; i++) {
    const item = filtered[i];
    // Calculate 7-day moving average from records up to this point
    const windowStart = Math.max(0, i - 6);
    const windowItems = filtered.slice(windowStart, i + 1);
    const ma = Math.round(windowItems.reduce((acc, curr) => acc + curr.sales, 0) / windowItems.length);

    result.push({
      date: item.date,
      sales: item.sales,
      movingAverage7d: ma,
      category: item.product_category,
    });
  }

  return result;
}

export function computeMonthlySalesTrend(records: CleanSalesRecord[]): MonthlyTrendPoint[] {
  const map = new Map<string, { total: number; count: number; dateObj: Date }>();

  for (const r of records) {
    const d = r.dateObj;
    const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const curr = map.get(monthKey) || { total: 0, count: 0, dateObj: d };
    curr.total += r.sales;
    curr.count += 1;
    map.set(monthKey, curr);
  }

  const sortedKeys = Array.from(map.keys()).sort();
  const points: MonthlyTrendPoint[] = [];

  let prevTotal: number | null = null;

  for (const key of sortedKeys) {
    const data = map.get(key)!;
    const avgDaily = Math.round(data.total / data.count);
    const totalSales = Math.round(data.total);

    const [yearStr, monthStr] = key.split('-');
    const dateHelper = new Date(Number(yearStr), Number(monthStr) - 1, 1);
    const monthLabel = dateHelper.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

    let momGrowthPercent: number | null = null;
    if (prevTotal !== null && prevTotal > 0) {
      momGrowthPercent = Number((((totalSales - prevTotal) / prevTotal) * 100).toFixed(1));
    }
    prevTotal = totalSales;

    points.push({
      monthKey: key,
      monthLabel,
      totalSales,
      averageDailySales: avgDaily,
      recordCount: data.count,
      momGrowthPercent,
    });
  }

  return points;
}

export function computeCategoryAnalysis(records: CleanSalesRecord[]): CategorySummary[] {
  const grandTotal = records.reduce((s, r) => s + r.sales, 0) || 1;
  const map = new Map<string, { totalSales: number; totalQty: number; totalPrice: number; count: number }>();

  for (const r of records) {
    const cat = r.product_category || 'Other';
    const curr = map.get(cat) || { totalSales: 0, totalQty: 0, totalPrice: 0, count: 0 };
    curr.totalSales += r.sales;
    curr.totalQty += r.quantity;
    curr.totalPrice += r.price;
    curr.count += 1;
    map.set(cat, curr);
  }

  const summaries: CategorySummary[] = [];
  for (const [category, data] of map.entries()) {
    summaries.push({
      category,
      totalSales: Math.round(data.totalSales),
      averageSales: Math.round(data.totalSales / data.count),
      averageQuantity: Math.round(data.totalQty / data.count),
      averagePrice: Number((data.totalPrice / data.count).toFixed(2)),
      recordCount: data.count,
      salesSharePercent: Number(((data.totalSales / grandTotal) * 100).toFixed(1)),
    });
  }

  summaries.sort((a, b) => b.totalSales - a.totalSales);
  return summaries;
}

export function computePromotionAnalysis(records: CleanSalesRecord[]): {
  groups: BinaryComparison[];
  upliftPercent: number;
} {
  let promoSales = 0, promoQty = 0, promoPrice = 0, promoCount = 0;
  let regularSales = 0, regularQty = 0, regularPrice = 0, regularCount = 0;

  for (const r of records) {
    if (r.promotion) {
      promoSales += r.sales;
      promoQty += r.quantity;
      promoPrice += r.price;
      promoCount++;
    } else {
      regularSales += r.sales;
      regularQty += r.quantity;
      regularPrice += r.price;
      regularCount++;
    }
  }

  const promoAvg = promoCount > 0 ? Math.round(promoSales / promoCount) : 0;
  const regularAvg = regularCount > 0 ? Math.round(regularSales / regularCount) : 0;

  const upliftPercent = regularAvg > 0 ? Number((((promoAvg - regularAvg) / regularAvg) * 100).toFixed(1)) : 0;

  return {
    groups: [
      {
        flag: 'Promotion Days',
        count: promoCount,
        totalSales: Math.round(promoSales),
        averageSales: promoAvg,
        averageQuantity: promoCount > 0 ? Math.round(promoQty / promoCount) : 0,
        averagePrice: promoCount > 0 ? Number((promoPrice / promoCount).toFixed(2)) : 0,
      },
      {
        flag: 'Non-Promotion Days',
        count: regularCount,
        totalSales: Math.round(regularSales),
        averageSales: regularAvg,
        averageQuantity: regularCount > 0 ? Math.round(regularQty / regularCount) : 0,
        averagePrice: regularCount > 0 ? Number((regularPrice / regularCount).toFixed(2)) : 0,
      },
    ],
    upliftPercent,
  };
}

export function computeHolidayAnalysis(records: CleanSalesRecord[]): {
  groups: BinaryComparison[];
  upliftPercent: number;
} {
  let holidaySales = 0, holidayQty = 0, holidayPrice = 0, holidayCount = 0;
  let nonHolidaySales = 0, nonHolidayQty = 0, nonHolidayPrice = 0, nonHolidayCount = 0;

  for (const r of records) {
    if (r.holiday) {
      holidaySales += r.sales;
      holidayQty += r.quantity;
      holidayPrice += r.price;
      holidayCount++;
    } else {
      nonHolidaySales += r.sales;
      nonHolidayQty += r.quantity;
      nonHolidayPrice += r.price;
      nonHolidayCount++;
    }
  }

  const holidayAvg = holidayCount > 0 ? Math.round(holidaySales / holidayCount) : 0;
  const nonHolidayAvg = nonHolidayCount > 0 ? Math.round(nonHolidaySales / nonHolidayCount) : 0;
  const upliftPercent = nonHolidayAvg > 0 ? Number((((holidayAvg - nonHolidayAvg) / nonHolidayAvg) * 100).toFixed(1)) : 0;

  return {
    groups: [
      {
        flag: 'Holiday Days',
        count: holidayCount,
        totalSales: Math.round(holidaySales),
        averageSales: holidayAvg,
        averageQuantity: holidayCount > 0 ? Math.round(holidayQty / holidayCount) : 0,
        averagePrice: holidayCount > 0 ? Number((holidayPrice / holidayCount).toFixed(2)) : 0,
      },
      {
        flag: 'Regular Days',
        count: nonHolidayCount,
        totalSales: Math.round(nonHolidaySales),
        averageSales: nonHolidayAvg,
        averageQuantity: nonHolidayCount > 0 ? Math.round(nonHolidayQty / nonHolidayCount) : 0,
        averagePrice: nonHolidayCount > 0 ? Number((nonHolidayPrice / nonHolidayCount).toFixed(2)) : 0,
      },
    ],
    upliftPercent,
  };
}

export function computeSeasonAnalysis(records: CleanSalesRecord[]): SeasonSummary[] {
  const map = new Map<string, { totalSales: number; totalQty: number; count: number }>();

  for (const r of records) {
    const s = r.season || 'Regular';
    const curr = map.get(s) || { totalSales: 0, totalQty: 0, count: 0 };
    curr.totalSales += r.sales;
    curr.totalQty += r.quantity;
    curr.count += 1;
    map.set(s, curr);
  }

  const seasonOrder = ['Spring', 'Summer', 'Fall', 'Winter'];
  const summaries: SeasonSummary[] = [];

  for (const [season, data] of map.entries()) {
    summaries.push({
      season,
      totalSales: Math.round(data.totalSales),
      averageSales: Math.round(data.totalSales / data.count),
      averageQuantity: Math.round(data.totalQty / data.count),
      recordCount: data.count,
    });
  }

  summaries.sort((a, b) => {
    const idxA = seasonOrder.indexOf(a.season);
    const idxB = seasonOrder.indexOf(b.season);
    if (idxA !== -1 && idxB !== -1) return idxA - idxB;
    return b.totalSales - a.totalSales;
  });

  return summaries;
}

export function computeWeekdayAnalysis(records: CleanSalesRecord[]): WeekdaySummary[] {
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const sums = Array.from({ length: 7 }, () => ({ totalSales: 0, totalQty: 0, count: 0 }));

  for (const r of records) {
    const day = r.dateObj.getDay();
    sums[day].totalSales += r.sales;
    sums[day].totalQty += r.quantity;
    sums[day].count += 1;
  }

  // Display Monday first through Sunday
  const displayOrder = [1, 2, 3, 4, 5, 6, 0];

  return displayOrder.map(dayIdx => {
    const item = sums[dayIdx];
    const avg = item.count > 0 ? Math.round(item.totalSales / item.count) : 0;
    const avgQty = item.count > 0 ? Math.round(item.totalQty / item.count) : 0;
    return {
      dayName: dayNames[dayIdx],
      dayIndex: dayIdx,
      averageSales: avg,
      totalSales: Math.round(item.totalSales),
      averageQuantity: avgQty,
      recordCount: item.count,
    };
  });
}

export function sampleScatterData(records: CleanSalesRecord[], sampleSize = 120): {
  customerPoints: CustomerSalesPoint[];
  pricePoints: PriceSalesPoint[];
  quantityPoints: QuantitySalesPoint[];
} {
  const step = Math.max(1, Math.floor(records.length / sampleSize));
  const customerPoints: CustomerSalesPoint[] = [];
  const pricePoints: PriceSalesPoint[] = [];
  const quantityPoints: QuantitySalesPoint[] = [];

  for (let i = 0; i < records.length; i += step) {
    const r = records[i];
    customerPoints.push({
      customers: r.customers,
      sales: r.sales,
      category: r.product_category,
      date: r.date,
    });
    pricePoints.push({
      price: r.price,
      sales: r.sales,
      quantity: r.quantity,
      category: r.product_category,
    });
    quantityPoints.push({
      quantity: r.quantity,
      sales: r.sales,
      price: r.price,
      category: r.product_category,
    });
  }

  return { customerPoints, pricePoints, quantityPoints };
}
