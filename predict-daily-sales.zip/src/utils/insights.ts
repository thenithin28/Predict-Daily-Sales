import { DatasetStatistics, TrainedModelSystem, CleanSalesRecord } from '../types';
import {
  computeCategoryAnalysis,
  computePromotionAnalysis,
  computeHolidayAnalysis,
  computeWeekdayAnalysis,
} from './salesAnalysis';
import { formatCurrency, formatNumber } from './predictionUtils';

export interface DynamicInsight {
  id: string;
  category: 'overview' | 'promotion' | 'performance' | 'trend' | 'feature';
  title: string;
  description: string;
  metric?: string;
  badge?: string;
}

export function generateDynamicInsights(
  stats: DatasetStatistics,
  modelSystem: TrainedModelSystem,
  records: CleanSalesRecord[]
): DynamicInsight[] {
  const insights: DynamicInsight[] = [];

  // 1. Dataset Overview
  insights.push({
    id: 'insight-total-records',
    category: 'overview',
    title: 'Historical Coverage',
    description: `The dataset encompasses ${formatNumber(stats.totalRecords)} verified daily business records from ${stats.dateRange.start} through ${stats.dateRange.end}, totaling ${formatCurrency(stats.totalSales)} in cumulative revenue.`,
    metric: `${formatNumber(stats.totalRecords)} Days`,
    badge: 'Dataset',
  });

  // 2. Average Daily Sales & Extreme Points
  insights.push({
    id: 'insight-daily-avg',
    category: 'overview',
    title: 'Daily Baseline Sales',
    description: `Average daily sales across all operational periods stand at ${formatCurrency(stats.averageDailySales)}. The single highest recorded sales day reached ${formatCurrency(stats.highestDailySales)} on ${stats.highestSalesDate}, while the minimum was ${formatCurrency(stats.lowestDailySales)} on ${stats.lowestSalesDate}.`,
    metric: formatCurrency(stats.averageDailySales),
    badge: 'Revenue Baseline',
  });

  // 3. Category Leader
  const catAnalysis = computeCategoryAnalysis(records);
  if (catAnalysis.length > 0) {
    const leader = catAnalysis[0];
    insights.push({
      id: 'insight-cat-leader',
      category: 'trend',
      title: 'Top Performing Product Category',
      description: `"${leader.category}" generates the highest total volume at ${formatCurrency(leader.totalSales)} (${leader.salesSharePercent}% of total business sales), maintaining an average daily revenue of ${formatCurrency(leader.averageSales)}.`,
      metric: `${leader.salesSharePercent}% Share`,
      badge: 'Category Leader',
    });
  }

  // 4. Promotional Impact
  const promoAnalysis = computePromotionAnalysis(records);
  const promoGroup = promoAnalysis.groups.find(g => g.flag.includes('Promotion'));
  const regGroup = promoAnalysis.groups.find(g => g.flag.includes('Non-Promotion'));
  if (promoGroup && regGroup) {
    const isPositive = promoAnalysis.upliftPercent >= 0;
    insights.push({
      id: 'insight-promotion-impact',
      category: 'promotion',
      title: 'Promotional Revenue Lift',
      description: `Active promotional days average ${formatCurrency(promoGroup.averageSales)} compared to ${formatCurrency(regGroup.averageSales)} on standard days, delivering an observed ${isPositive ? '+' : ''}${promoAnalysis.upliftPercent}% sales differential.`,
      metric: `${isPositive ? '+' : ''}${promoAnalysis.upliftPercent}% Lift`,
      badge: 'Marketing Lift',
    });
  }

  // 5. Holiday Impact
  const holidayAnalysis = computeHolidayAnalysis(records);
  const holGroup = holidayAnalysis.groups.find(g => g.flag.includes('Holiday'));
  if (holGroup && holGroup.count > 0) {
    const isPositive = holidayAnalysis.upliftPercent >= 0;
    insights.push({
      id: 'insight-holiday-impact',
      category: 'trend',
      title: 'Holiday Trading Velocity',
      description: `During observed calendar holidays (${stats.holidayDays} days), average daily revenue reached ${formatCurrency(holGroup.averageSales)}, showing a ${isPositive ? '+' : ''}${holidayAnalysis.upliftPercent}% variation compared to non-holiday operations.`,
      metric: `${isPositive ? '+' : ''}${holidayAnalysis.upliftPercent}%`,
      badge: 'Seasonal Calendar',
    });
  }

  // 6. Day of Week Pattern
  const weekdayAnalysis = computeWeekdayAnalysis(records);
  if (weekdayAnalysis.length > 0) {
    const sortedDays = [...weekdayAnalysis].sort((a, b) => b.averageSales - a.averageSales);
    const bestDay = sortedDays[0];
    const lowestDay = sortedDays[sortedDays.length - 1];
    insights.push({
      id: 'insight-weekday-peak',
      category: 'trend',
      title: 'Peak Weekly Trading Day',
      description: `${bestDay.dayName} represents the strongest trading period of the week with an average of ${formatCurrency(bestDay.averageSales)} per day, compared to ${lowestDay.dayName} at ${formatCurrency(lowestDay.averageSales)}.`,
      metric: bestDay.dayName,
      badge: 'Peak Velocity',
    });
  }

  // 7. Best Regression Model
  const bestModelName = modelSystem.bestModelType === 'randomForest' ? 'Random Forest Regression' : 'Linear Regression';
  const bestMetrics = modelSystem.bestModelType === 'randomForest' ? modelSystem.randomForest : modelSystem.linearRegression;
  const altMetrics = modelSystem.bestModelType === 'randomForest' ? modelSystem.linearRegression : modelSystem.randomForest;
  const rmseDiff = Number((altMetrics.rmse - bestMetrics.rmse).toFixed(1));

  insights.push({
    id: 'insight-model-benchmark',
    category: 'performance',
    title: 'Optimal ML Architecture',
    description: `${bestModelName} achieved superior out-of-sample generalization with test-set RMSE of ${formatCurrency(bestMetrics.rmse)} (vs ${formatCurrency(altMetrics.rmse)}) and an R² score of ${bestMetrics.r2}, outperforming by ${formatCurrency(rmseDiff)} lower root mean squared error.`,
    metric: `R² = ${bestMetrics.r2}`,
    badge: 'Best Model',
  });

  // 8. Key Influential Feature
  const bestImportances = bestMetrics.featureImportance;
  if (bestImportances && bestImportances.length > 0) {
    const topFeature = bestImportances[0];
    insights.push({
      id: 'insight-feature-importance',
      category: 'feature',
      title: 'Primary Sales Predictive Driver',
      description: `Analysis reveals "${topFeature.feature}" is the single most influential predictive feature, driving ${topFeature.normalizedImportance}% of total model variance reduction in the chronological test evaluation.`,
      metric: `${topFeature.normalizedImportance}% Weight`,
      badge: 'Feature Driver',
    });
  }

  return insights;
}
