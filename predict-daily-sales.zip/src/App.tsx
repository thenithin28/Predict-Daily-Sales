import React, { useState, useEffect } from 'react';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { DailySalesPredictor } from './pages/DailySalesPredictor';
import { SalesAnalysis } from './pages/SalesAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import {
  CleanSalesRecord,
  DatasetStatistics,
  TrainedModelSystem,
  PredictionResult,
  ForecastDayResult,
  PredictionInput,
} from './types';
import { loadDefaultDataset } from './services/datasetService';
import { trainModelsPipeline } from './ml/modelTraining';
import { runPrediction } from './utils/predictionUtils';
import { generateMultiDayForecast } from './utils/forecastUtils';
import { Sparkles, AlertCircle, RefreshCw } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Data & ML State
  const [records, setRecords] = useState<CleanSalesRecord[]>([]);
  const [stats, setStats] = useState<DatasetStatistics | null>(null);
  const [modelSystem, setModelSystem] = useState<TrainedModelSystem | null>(null);
  const [activePrediction, setActivePrediction] = useState<PredictionResult | null>(null);
  const [activeForecast, setActiveForecast] = useState<ForecastDayResult[] | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const initDataAndModels = async () => {
    setIsLoading(true);
    setLoadError(null);

    try {
      // 1. Load CSV
      const { cleaned, stats: calculatedStats } = await loadDefaultDataset();
      setRecords(cleaned);
      setStats(calculatedStats);

      // 2. Train Models in browser
      const trained = trainModelsPipeline(cleaned);
      setModelSystem(trained);

      // 3. Generate an initial prediction & 7-day forecast for the day following the dataset end date
      const lastRec = cleaned[cleaned.length - 1];
      const nextDate = new Date(lastRec.dateObj);
      nextDate.setDate(nextDate.getDate() + 1);
      const nextDateStr = nextDate.toISOString().split('T')[0];

      const initialInput: PredictionInput = {
        date: nextDateStr,
        product_category: calculatedStats.categories[0] || 'Electronics',
        quantity: Math.round(calculatedStats.averageQuantity * 1.1),
        price: calculatedStats.averagePrice,
        previous_sales: lastRec.sales,
        customers: Math.round(calculatedStats.averageCustomers * 1.1),
        promotion: true,
        holiday: false,
        season: calculatedStats.seasons[0] || 'Fall',
      };

      const initialPred = runPrediction(initialInput, trained);
      setActivePrediction(initialPred);

      const initialFore = generateMultiDayForecast(initialInput, 7, trained);
      setActiveForecast(initialFore);
    } catch (err: any) {
      console.error('Error initializing sales applet:', err);
      setLoadError(err.message || 'Failed to load sales dataset.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initDataAndModels();
  }, []);

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 font-sans flex flex-col antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        totalRecords={stats?.totalRecords || 0}
        bestModelName={
          modelSystem
            ? modelSystem.bestModelType === 'randomForest'
              ? 'Random Forest'
              : 'Linear Regression'
            : ''
        }
      />

      {/* Main Content Area */}
      <div className="lg:pl-72 flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          onOpenSidebar={() => setIsSidebarOpen(true)}
          stats={
            stats || {
              totalRecords: 0,
              totalSales: 0,
              averageDailySales: 0,
              highestDailySales: 0,
              lowestDailySales: 0,
              highestSalesDate: '',
              lowestSalesDate: '',
              averageQuantity: 0,
              averagePrice: 0,
              totalCustomers: 0,
              averageCustomers: 0,
              promotionDays: 0,
              promotionPercent: 0,
              holidayDays: 0,
              holidayPercent: 0,
              dateRange: { start: '', end: '' },
              categories: [],
              seasons: [],
            }
          }
          modelSystem={modelSystem}
          records={records}
          activePrediction={activePrediction}
          activeForecast={activeForecast}
          onReloadDefaultData={initDataAndModels}
          isLoadingData={isLoading}
        />

        {/* View Routing */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto min-w-0">
          {isLoading ? (
            <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-sm animate-bounce">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="text-center">
                <h3 className="text-base font-bold text-slate-900">
                  Initializing Machine Learning Pipeline
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xs">
                  Loading historical CSV, computing chronological lag features, and training regression models in browser...
                </p>
              </div>
            </div>
          ) : loadError ? (
            <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-4">
              <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="text-center">
                <h3 className="text-base font-bold text-slate-900">
                  Data Processing Error
                </h3>
                <p className="text-xs text-rose-600 mt-1 max-w-sm">
                  {loadError}
                </p>
                <button
                  onClick={initDataAndModels}
                  className="mt-4 px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors inline-flex items-center gap-2"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Data Loading</span>
                </button>
              </div>
            </div>
          ) : !stats || !modelSystem ? null : (
            <>
              {activeTab === 'dashboard' && (
                <Dashboard
                  stats={stats}
                  records={records}
                  modelSystem={modelSystem}
                  onNavigateToPredictor={() => setActiveTab('predictor')}
                />
              )}

              {activeTab === 'predictor' && (
                <DailySalesPredictor
                  stats={stats}
                  records={records}
                  modelSystem={modelSystem}
                  activePrediction={activePrediction}
                  onSetPrediction={setActivePrediction}
                  activeForecast={activeForecast}
                  onSetForecast={setActiveForecast}
                />
              )}

              {activeTab === 'analysis' && (
                <SalesAnalysis
                  stats={stats}
                  records={records}
                />
              )}

              {activeTab === 'performance' && (
                <ModelPerformance
                  modelSystem={modelSystem}
                  stats={stats}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
