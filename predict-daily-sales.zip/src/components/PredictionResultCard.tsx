import React from 'react';
import { Sparkles, Calendar, TrendingUp, TrendingDown, Minus, Info, ShieldAlert, Cpu } from 'lucide-react';
import { PredictionResult } from '../types';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';

interface PredictionResultCardProps {
  result: PredictionResult;
  id?: string;
}

export const PredictionResultCard: React.FC<PredictionResultCardProps> = ({
  result,
  id,
}) => {
  const formattedDate = new Date(result.predictionDate).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const isAbove = result.interpretation === 'above';
  const isBelow = result.interpretation === 'below';

  const interpretationBadge = {
    above: {
      text: `Above Average (+${result.diffPercent}%)`,
      bg: 'bg-emerald-500/10 text-emerald-700 border-emerald-300',
      icon: TrendingUp,
      message: 'The predicted sales are above the historical average daily sales in the dataset.',
    },
    around: {
      text: `Around Average (${result.diffPercent >= 0 ? '+' : ''}${result.diffPercent}%)`,
      bg: 'bg-blue-500/10 text-blue-700 border-blue-300',
      icon: Minus,
      message: 'The predicted sales are close to the historical average daily sales.',
    },
    below: {
      text: `Below Average (${result.diffPercent}%)`,
      bg: 'bg-amber-500/10 text-amber-700 border-amber-300',
      icon: TrendingDown,
      message: 'The predicted sales are below the historical average daily sales in the dataset.',
    },
  }[result.interpretation];

  const BadgeIcon = interpretationBadge.icon;

  return (
    <div
      id={id || 'card-prediction-result'}
      className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl shadow-md border border-slate-700/80 p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden"
    >
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div>
        {/* Header with Title and Model */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>Daily Sales Prediction</span>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-xs text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold">{result.modelUsed}</span>
          </div>
        </div>

        {/* Primary Predicted Sales Value */}
        <div className="my-3">
          <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold block mb-1">
            Predicted Expected Sales
          </span>
          <div className="text-4xl sm:text-5xl font-black tracking-tight text-white flex items-baseline gap-2">
            <span>{formatCurrency(result.predictedSales)}</span>
          </div>
        </div>

        {/* Expected Range derived from model test error */}
        <div className="mt-4 p-3.5 rounded-lg bg-slate-800/80 border border-slate-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Expected Range (90% Confidence Interval)
            </span>
            <div className="text-base sm:text-lg font-bold text-emerald-300 mt-0.5">
              {formatCurrency(result.lowerEstimate)} – {formatCurrency(result.upperEstimate)}
            </div>
          </div>
          <div className="text-right sm:border-l sm:border-slate-700 sm:pl-4">
            <span className="text-[11px] font-medium text-slate-400 block">
              Test Error Margin
            </span>
            <span className="text-xs font-semibold text-slate-200">
              ± {formatCurrency(result.margin)}
            </span>
          </div>
        </div>

        {/* Context metadata & Interpretation */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-800/40 border border-slate-700/40">
            <span className="text-slate-400 block mb-1">Target Date &amp; Category</span>
            <div className="font-semibold text-white flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{formattedDate}</span>
            </div>
            <div className="text-slate-300 text-[11px] mt-0.5">
              Category: <strong className="text-white">{result.input.product_category}</strong> ({result.input.season})
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-800/40 border border-slate-700/40">
            <span className="text-slate-400 block mb-1">Benchmark Relative Position</span>
            <div className="flex items-center gap-1.5 font-semibold text-white">
              <BadgeIcon className="w-3.5 h-3.5 text-emerald-400" />
              <span>{interpretationBadge.text}</span>
            </div>
            <div className="text-slate-300 text-[11px] mt-0.5">
              Historical Avg: <strong>{formatCurrency(result.historicalAverage)}</strong> / day
            </div>
          </div>
        </div>

        {/* Interpretation sentence */}
        <div className="mt-3 text-xs text-slate-300 flex items-start gap-2 bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/30">
          <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <span>{interpretationBadge.message}</span>
        </div>
      </div>

      {/* Mandatory PRD Business Disclaimer */}
      <div className="mt-6 pt-3.5 border-t border-slate-700/60 text-[11px] text-slate-400 flex items-start gap-2">
        <ShieldAlert className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-slate-300">Disclaimer:</strong> Sales predictions are estimates generated from historical data patterns and available input factors. Actual future sales may differ due to changing market conditions, customer behavior, competition, pricing, promotions, and other factors.
        </p>
      </div>
    </div>
  );
};
