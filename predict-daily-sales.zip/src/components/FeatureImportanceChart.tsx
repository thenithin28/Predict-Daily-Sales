import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from 'recharts';
import { FeatureImportanceItem } from '../types';

interface FeatureImportanceChartProps {
  importances: FeatureImportanceItem[];
  modelName: string;
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({
  importances,
  modelName,
}) => {
  if (!importances || importances.length === 0) {
    return <div className="p-8 text-center text-slate-400 text-xs">No feature rankings available.</div>;
  }

  // Display top 10 features cleanly
  const topFeatures = importances.slice(0, 10).map(f => {
    // Format feature name for display
    let label = f.feature
      .replace(/^cat_/, 'Category: ')
      .replace(/^season_/, 'Season: ')
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase());

    if (f.feature === 'lag_1') label = 'Lag Sales (Prior Day)';
    if (f.feature === 'lag_7') label = 'Lag 7-Day Sales';
    if (f.feature === 'lag_30') label = 'Lag 30-Day Sales';
    if (f.feature === 'roll_7') label = '7-Day Rolling Avg';
    if (f.feature === 'roll_14') label = '14-Day Rolling Avg';
    if (f.feature === 'roll_30') label = '30-Day Rolling Avg';
    if (f.feature === 'revenue_potential') label = 'Revenue Potential (Qty × Price)';

    return {
      name: label,
      rawName: f.feature,
      weight: f.normalizedImportance,
      importance: f.importance,
    };
  });

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={topFeatures}
          margin={{ top: 5, right: 30, bottom: 5, left: 120 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
          <XAxis
            type="number"
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            unit="%"
          />
          <YAxis
            type="category"
            dataKey="name"
            tick={{ fontSize: 10.5, fill: '#334155' }}
            tickLine={false}
            width={115}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const data = payload[0].payload;
                return (
                  <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg border border-slate-800 space-y-1">
                    <div className="font-semibold text-slate-200">{data.name}</div>
                    <div className="text-emerald-400 font-bold">
                      Importance Weight: {data.weight}%
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Raw Model Gain / Coeff: {data.importance}
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey="weight" name="Importance" radius={[0, 4, 4, 0]}>
            {topFeatures.map((_, index) => (
              <Cell
                key={`cell-${index}`}
                fill={index === 0 ? '#10b981' : index < 3 ? '#059669' : '#34d399'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
