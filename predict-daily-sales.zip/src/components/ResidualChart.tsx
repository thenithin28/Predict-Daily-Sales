import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { PredictionPoint } from '../types';
import { formatCurrency } from '../utils/predictionUtils';

interface ResidualChartProps {
  predictions: PredictionPoint[];
  meanResidual: number;
  maxPositiveResidual: number;
  maxNegativeResidual: number;
}

export const ResidualChart: React.FC<ResidualChartProps> = ({
  predictions,
  meanResidual,
  maxPositiveResidual,
  maxNegativeResidual,
}) => {
  const [viewMode, setViewMode] = useState<'scatter' | 'distribution'>('scatter');

  if (!predictions || predictions.length === 0) {
    return <div className="p-8 text-center text-slate-400 text-xs">No residual data.</div>;
  }

  // Distribution Bins
  const residuals = predictions.map(p => p.residual);
  const minRes = Math.min(...residuals);
  const maxRes = Math.max(...residuals);
  const binCount = 9;
  const binWidth = (maxRes - minRes) / binCount || 100;

  const distributionBins: { binLabel: string; count: number; rangeCenter: number }[] = [];
  for (let b = 0; b < binCount; b++) {
    const start = minRes + b * binWidth;
    const end = start + binWidth;
    const count = residuals.filter(r => (b === binCount - 1 ? r >= start && r <= end : r >= start && r < end)).length;
    const center = Math.round((start + end) / 2);
    distributionBins.push({
      binLabel: `${(center / 1000).toFixed(1)}k`,
      count,
      rangeCenter: center,
    });
  }

  return (
    <div className="space-y-4">
      {/* Residual Statistics Bar */}
      <div className="grid grid-cols-3 gap-3 text-xs">
        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/70 text-center">
          <span className="text-slate-500 block text-[11px]">Mean Residual (Bias)</span>
          <span className="font-mono font-bold text-slate-800">
            {meanResidual >= 0 ? '+' : ''}
            {formatCurrency(meanResidual)}
          </span>
        </div>
        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/70 text-center">
          <span className="text-slate-500 block text-[11px]">Max Under-Prediction</span>
          <span className="font-mono font-bold text-emerald-600">
            +{formatCurrency(maxPositiveResidual)}
          </span>
        </div>
        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/70 text-center">
          <span className="text-slate-500 block text-[11px]">Max Over-Prediction</span>
          <span className="font-mono font-bold text-rose-600">
            {formatCurrency(maxNegativeResidual)}
          </span>
        </div>
      </div>

      {/* Chart View Toggle */}
      <div className="flex items-center justify-end gap-1 text-xs">
        <button
          onClick={() => setViewMode('scatter')}
          className={`px-2.5 py-1 rounded font-medium transition-colors ${
            viewMode === 'scatter'
              ? 'bg-slate-900 text-white'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Residual vs Predicted
        </button>
        <button
          onClick={() => setViewMode('distribution')}
          className={`px-2.5 py-1 rounded font-medium transition-colors ${
            viewMode === 'distribution'
              ? 'bg-slate-900 text-white'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Error Distribution
        </button>
      </div>

      {/* Primary Chart Canvas */}
      <div className="w-full h-64">
        <ResponsiveContainer width="100%" height="100%">
          {viewMode === 'scatter' ? (
            <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="predicted"
                name="Predicted Sales"
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                label={{
                  value: 'Predicted Sales ($)',
                  position: 'insideBottom',
                  offset: -12,
                  fontSize: 11,
                  fill: '#64748b',
                }}
              />
              <YAxis
                type="number"
                dataKey="residual"
                name="Residual"
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                label={{
                  value: 'Residual ($)',
                  angle: -90,
                  position: 'insideLeft',
                  offset: 0,
                  fontSize: 11,
                  fill: '#64748b',
                }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data: PredictionPoint = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg border border-slate-800 space-y-1">
                        <div className="font-semibold text-slate-300">{data.date}</div>
                        <div className="flex justify-between gap-4">
                          <span>Predicted:</span>
                          <span className="font-mono">{formatCurrency(data.predicted)}</span>
                        </div>
                        <div className="flex justify-between gap-4">
                          <span>Actual:</span>
                          <span className="font-mono">{formatCurrency(data.actual)}</span>
                        </div>
                        <div className="flex justify-between gap-4 font-bold text-amber-400">
                          <span>Residual:</span>
                          <span className="font-mono">
                            {data.residual >= 0 ? '+' : ''}
                            {formatCurrency(data.residual)}
                          </span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine y={0} stroke="#ef4444" strokeDasharray="3 3" strokeWidth={1.5} />
              <Scatter
                name="Residuals"
                data={predictions}
                fill="#6366f1"
                shape="circle"
                fillOpacity={0.7}
              />
            </ScatterChart>
          ) : (
            <BarChart data={distributionBins} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="binLabel"
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickLine={false}
                label={{
                  value: 'Residual Bucket ($k)',
                  position: 'insideBottom',
                  offset: -12,
                  fontSize: 11,
                  fill: '#64748b',
                }}
              />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2 rounded-lg text-xs shadow">
                        <div>Residual Center: ~${data.rangeCenter}</div>
                        <div className="font-bold text-emerald-400">Frequency: {data.count} observations</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="count" name="Count" fill="#6366f1" radius={[4, 4, 0, 0]} />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
};
