import React from 'react';
import { X, Calendar, Tag, DollarSign, Package, Users, TrendingUp, Sparkles, CheckCircle2 } from 'lucide-react';
import { CleanSalesRecord } from '../types';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';
import { extractDateFeatures } from '../ml/dateFeatures';

interface SalesDetailsModalProps {
  record: CleanSalesRecord | null;
  onClose: () => void;
  previousSalesInDataset?: number;
  movingAverage7d?: number;
}

export const SalesDetailsModal: React.FC<SalesDetailsModalProps> = ({
  record,
  onClose,
  previousSalesInDataset,
  movingAverage7d,
}) => {
  if (!record) return null;

  const dateFeats = extractDateFeatures(record.dateObj);
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayName = dayNames[dateFeats.dayOfWeek];

  const revenuePotential = record.quantity * record.price;
  const prevBenchmark = previousSalesInDataset !== undefined ? previousSalesInDataset : record.previous_sales;
  const changeFromPrev = record.sales - prevBenchmark;
  const changePercent = prevBenchmark > 0 ? Number(((changeFromPrev / prevBenchmark) * 100).toFixed(1)) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                {record.sales_id}
              </span>
              <span className="text-sm font-semibold text-slate-800">
                Sales Transaction Record
              </span>
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              Trading Day: {record.date} ({dayName})
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Main Hero KPI */}
          <div className="p-5 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider block">
                Recorded Daily Sales
              </span>
              <div className="text-3xl sm:text-4xl font-black text-white mt-0.5">
                {formatCurrency(record.sales)}
              </div>
              <div className="text-xs text-slate-300 mt-1 flex items-center gap-1.5">
                <span>Momentum:</span>
                <span className={changeFromPrev >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                  {changeFromPrev >= 0 ? '+' : ''}{formatCurrency(changeFromPrev)} ({changePercent >= 0 ? '+' : ''}{changePercent}%)
                </span>
                <span className="text-slate-500">vs prior period</span>
              </div>
            </div>

            <div className="text-right sm:border-l sm:border-slate-800 sm:pl-6">
              <span className="text-xs text-slate-400 block font-medium">Category</span>
              <span className="text-sm font-bold text-emerald-400">{record.product_category}</span>
              <span className="text-xs text-slate-400 block mt-1">Season</span>
              <span className="text-xs font-semibold text-slate-200">{record.season}</span>
            </div>
          </div>

          {/* Business Factors Grid */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Observed Transaction Factors
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                <span className="text-[11px] text-slate-500 block">Quantity Sold</span>
                <span className="text-base font-bold text-slate-900">{formatNumber(record.quantity)} units</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                <span className="text-[11px] text-slate-500 block">Average Unit Price</span>
                <span className="text-base font-bold text-slate-900">{formatCurrency(record.price)}</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                <span className="text-[11px] text-slate-500 block">Store Customers</span>
                <span className="text-base font-bold text-slate-900">{formatNumber(record.customers)}</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                <span className="text-[11px] text-slate-500 block">Revenue Potential</span>
                <span className="text-base font-bold text-slate-900">{formatCurrency(revenuePotential)}</span>
              </div>
            </div>
          </div>

          {/* Derived Features Grid */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Engineered Time &amp; History Features
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">Day of Week</span>
                <span className="font-bold text-slate-800">{dayName}</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {dateFeats.isWeekend ? 'Weekend Period' : 'Weekday Period'}
                </span>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">Quarter &amp; Month</span>
                <span className="font-bold text-slate-800">Q{dateFeats.quarter} (Month {dateFeats.month})</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">Week {dateFeats.weekOfYear} of year</span>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">7-Day Moving Avg</span>
                <span className="font-bold text-slate-800">
                  {movingAverage7d ? formatCurrency(movingAverage7d) : formatCurrency(record.sales)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">Historical rolling trend</span>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">Promotional Status</span>
                <span className={`font-bold ${record.promotion ? 'text-emerald-700' : 'text-slate-700'}`}>
                  {record.promotion ? 'Active Promotion' : 'No Promotion'}
                </span>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">Holiday Status</span>
                <span className={`font-bold ${record.holiday ? 'text-purple-700' : 'text-slate-700'}`}>
                  {record.holiday ? 'Calendar Holiday' : 'Regular Operating Day'}
                </span>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-white">
                <span className="text-slate-500 block">Prior Day Sales</span>
                <span className="font-bold text-slate-800">
                  {formatCurrency(record.previous_sales)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
