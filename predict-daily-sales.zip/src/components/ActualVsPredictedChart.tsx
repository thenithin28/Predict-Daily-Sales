import React from 'react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { PredictionPoint } from '../types';
import { formatCurrency } from '../utils/predictionUtils';

interface ActualVsPredictedChartProps {
  predictions: PredictionPoint[];
  modelName: string;
}

export const ActualVsPredictedChart: React.FC<ActualVsPredictedChartProps> = ({
  predictions,
  modelName,
}) => {
  if (!predictions || predictions.length === 0) {
    return <div className="p-8 text-center text-slate-400 text-xs">No prediction test points available.</div>;
  }

  // Determine min and max for uniform square scale
  const actuals = predictions.map(p => p.actual);
  const preds = predictions.map(p => p.predicted);
  const minVal = Math.min(...actuals, ...preds);
  const maxVal = Math.max(...actuals, ...preds);
  const padding = (maxVal - minVal) * 0.05;

  const domain = [Math.max(0, Math.floor(minVal - padding)), Math.ceil(maxVal + padding)];

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 15, right: 25, bottom: 25, left: 15 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis
            type="number"
            dataKey="actual"
            name="Actual Sales"
            domain={domain}
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
            label={{
              value: 'Actual Test Sales ($)',
              position: 'insideBottom',
              offset: -12,
              fontSize: 11,
              fill: '#64748b',
            }}
          />
          <YAxis
            type="number"
            dataKey="predicted"
            name="Predicted Sales"
            domain={domain}
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
            label={{
              value: 'Predicted Sales ($)',
              angle: -90,
              position: 'insideLeft',
              offset: 0,
              fontSize: 11,
              fill: '#64748b',
            }}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const data: PredictionPoint = payload[0].payload;
                return (
                  <div className="bg-slate-900 text-white p-3 rounded-lg text-xs shadow-lg border border-slate-800 space-y-1">
                    <div className="font-semibold text-slate-300 border-b border-slate-800 pb-1">
                      {data.date} (Test Observation #{data.index + 1})
                    </div>
                    <div className="flex justify-between gap-4 text-blue-400">
                      <span>Actual Sales:</span>
                      <span className="font-mono font-bold">{formatCurrency(data.actual)}</span>
                    </div>
                    <div className="flex justify-between gap-4 text-emerald-400">
                      <span>Predicted Sales:</span>
                      <span className="font-mono font-bold">{formatCurrency(data.predicted)}</span>
                    </div>
                    <div className="flex justify-between gap-4 text-slate-400 pt-1 border-t border-slate-800">
                      <span>Residual (Diff):</span>
                      <span
                        className={`font-mono font-bold ${
                          data.residual >= 0 ? 'text-amber-400' : 'text-purple-400'
                        }`}
                      >
                        {data.residual >= 0 ? '+' : ''}
                        {formatCurrency(data.residual)}
                      </span>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />

          {/* Ideal 45-degree Perfect Prediction Line (y = x) */}
          <ReferenceLine
            segment={[
              { x: domain[0], y: domain[0] },
              { x: domain[1], y: domain[1] },
            ]}
            stroke="#94a3b8"
            strokeDasharray="4 4"
            strokeWidth={1.5}
            label={{
              value: 'Ideal Perfect Fit (y = x)',
              position: 'insideTopLeft',
              fill: '#94a3b8',
              fontSize: 10,
            }}
          />

          <Scatter
            name={modelName}
            data={predictions}
            fill="#10b981"
            shape="circle"
            stroke="#059669"
            strokeWidth={1}
            fillOpacity={0.7}
          />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
};
