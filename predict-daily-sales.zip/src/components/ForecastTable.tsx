import React from 'react';
import { ForecastDayResult } from '../types';
import { formatCurrency } from '../utils/predictionUtils';
import { Calendar, Tag, Sparkles } from 'lucide-react';

interface ForecastTableProps {
  forecasts: ForecastDayResult[];
}

export const ForecastTable: React.FC<ForecastTableProps> = ({ forecasts }) => {
  if (!forecasts || forecasts.length === 0) return null;

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-600" />
            Recursive Multi-Day Forecast Horizon ({forecasts.length} Days)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Chronologically propagated sales forecast with interval error estimates
          </p>
        </div>

        <div className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 self-start sm:self-auto">
          Total Forecast Volume:{' '}
          {formatCurrency(forecasts.reduce((sum, f) => sum + f.predictedSales, 0))}
        </div>
      </div>

      {/* Internal scrollable table wrapper */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
              <th className="py-2.5 px-4">Step</th>
              <th className="py-2.5 px-4">Date</th>
              <th className="py-2.5 px-4">Weekday</th>
              <th className="py-2.5 px-4">Category</th>
              <th className="py-2.5 px-4">Season</th>
              <th className="py-2.5 px-4">Flags</th>
              <th className="py-2.5 px-4 text-right">Predicted Sales</th>
              <th className="py-2.5 px-4 text-right">Lower Bound</th>
              <th className="py-2.5 px-4 text-right">Upper Bound</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {forecasts.map(row => (
              <tr
                key={row.step}
                className={`hover:bg-slate-50/60 transition-colors ${
                  row.isWeekend ? 'bg-amber-50/20' : ''
                }`}
              >
                <td className="py-2.5 px-4 font-mono text-slate-400">#{row.step}</td>
                <td className="py-2.5 px-4 font-medium text-slate-900">{row.date}</td>
                <td className="py-2.5 px-4">
                  <span className={row.isWeekend ? 'font-semibold text-amber-700' : 'text-slate-600'}>
                    {row.dayOfWeek}
                  </span>
                </td>
                <td className="py-2.5 px-4">{row.product_category}</td>
                <td className="py-2.5 px-4">{row.season}</td>
                <td className="py-2.5 px-4">
                  <div className="flex items-center gap-1 flex-wrap">
                    {row.promotion && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                        Promo
                      </span>
                    )}
                    {row.holiday && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-800">
                        Holiday
                      </span>
                    )}
                    {row.isWeekend && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800">
                        Weekend
                      </span>
                    )}
                    {!row.promotion && !row.holiday && !row.isWeekend && (
                      <span className="text-slate-400 text-[11px]">—</span>
                    )}
                  </div>
                </td>
                <td className="py-2.5 px-4 text-right font-bold text-slate-900">
                  {formatCurrency(row.predictedSales)}
                </td>
                <td className="py-2.5 px-4 text-right text-slate-500 font-mono">
                  {formatCurrency(row.lowerEstimate)}
                </td>
                <td className="py-2.5 px-4 text-right text-slate-500 font-mono">
                  {formatCurrency(row.upperEstimate)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
