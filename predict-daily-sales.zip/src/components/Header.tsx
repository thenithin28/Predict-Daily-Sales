import React, { useState } from 'react';
import { Menu, Download, CheckCircle2, AlertCircle, RefreshCw, FileText } from 'lucide-react';
import { NavTab } from './Sidebar';
import { DatasetStatistics, TrainedModelSystem, CleanSalesRecord, PredictionResult, ForecastDayResult } from '../types';
import { generatePdfReport } from '../utils/reportGenerator';

interface HeaderProps {
  activeTab: NavTab;
  onOpenSidebar: () => void;
  stats: DatasetStatistics;
  modelSystem: TrainedModelSystem | null;
  records: CleanSalesRecord[];
  activePrediction: PredictionResult | null;
  activeForecast: ForecastDayResult[] | null;
  onReloadDefaultData: () => void;
  isLoadingData: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenSidebar,
  stats,
  modelSystem,
  records,
  activePrediction,
  activeForecast,
  onReloadDefaultData,
  isLoadingData,
}) => {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [reportError, setReportError] = useState<string | null>(null);
  const [reportSuccess, setReportSuccess] = useState(false);

  const titles: Record<NavTab, { title: string; subtitle: string }> = {
    dashboard: {
      title: 'Sales Intelligence Dashboard',
      subtitle: 'Comprehensive analysis of historical daily sales records and business drivers',
    },
    predictor: {
      title: 'Daily Sales Predictor',
      subtitle: 'Inference engine estimating future daily sales with confidence intervals',
    },
    analysis: {
      title: 'Sales & Behavior Analysis',
      subtitle: 'Deep-dive into product categories, promotions, seasonal velocity, and records',
    },
    performance: {
      title: 'Model Performance & Evaluation',
      subtitle: 'Chronological test-set metrics comparing Linear Regression and Random Forest',
    },
  };

  const handleDownloadReport = async () => {
    if (!modelSystem || records.length === 0) return;
    setIsGeneratingPdf(true);
    setReportError(null);
    setReportSuccess(false);

    try {
      await generatePdfReport({
        stats,
        modelSystem,
        records,
        activePrediction,
        activeForecast,
      });
      setReportSuccess(true);
      setTimeout(() => setReportSuccess(false), 3500);
    } catch (err: any) {
      setReportError(err.message || 'Unable to generate the report. Please try again.');
      setTimeout(() => setReportError(null), 5000);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const currentInfo = titles[activeTab];

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-8 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSidebar}
          className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight leading-tight">
            {currentInfo.title}
          </h1>
          <p className="text-xs text-slate-500 hidden sm:block">
            {currentInfo.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2.5 self-end sm:self-auto shrink-0">
        {/* Dataset reload button */}
        <button
          onClick={onReloadDefaultData}
          disabled={isLoadingData}
          title="Reload historical dataset"
          className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isLoadingData ? 'animate-spin text-emerald-600' : ''}`} />
        </button>

        {/* Model Status Pill */}
        {modelSystem && (
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200/80 text-xs text-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-slate-800">
              {modelSystem.bestModelType === 'randomForest' ? 'Random Forest' : 'Linear Regression'}
            </span>
            <span className="text-slate-400">|</span>
            <span className="text-slate-500">
              R² = {modelSystem.bestModelType === 'randomForest' ? modelSystem.randomForest.r2 : modelSystem.linearRegression.r2}
            </span>
          </div>
        )}

        {/* Download PDF Report Button */}
        <button
          id="btn-download-pdf-report"
          onClick={handleDownloadReport}
          disabled={isGeneratingPdf || !modelSystem}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white text-xs font-semibold shadow-xs transition-colors disabled:opacity-50"
        >
          {isGeneratingPdf ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Generating PDF...</span>
            </>
          ) : reportSuccess ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Report Downloaded</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF Report</span>
            </>
          )}
        </button>
      </div>

      {/* Floating Error Notification if PDF generation fails */}
      {reportError && (
        <div className="absolute top-16 right-4 sm:right-8 z-50 bg-rose-50 border border-rose-200 text-rose-800 px-4 py-2.5 rounded-lg text-xs shadow-md flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{reportError}</span>
        </div>
      )}
    </header>
  );
};
