import React from 'react';
import { Trophy, CheckCircle2, TrendingDown, ArrowUpRight, HelpCircle } from 'lucide-react';
import { ModelMetrics } from '../types';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';

interface ModelMetricsCardProps {
  linearMetrics: ModelMetrics;
  rfMetrics: ModelMetrics;
  bestModelType: 'linearRegression' | 'randomForest';
}

export const ModelMetricsCard: React.FC<ModelMetricsCardProps> = ({
  linearMetrics,
  rfMetrics,
  bestModelType,
}) => {
  const isRfBest = bestModelType === 'randomForest';

  const rows = [
    {
      label: 'MAE (Mean Absolute Error)',
      description: 'Average magnitude of prediction errors in dollar terms. Lower is better.',
      lrVal: formatCurrency(linearMetrics.mae),
      rfVal: formatCurrency(rfMetrics.mae),
      winner: linearMetrics.mae <= rfMetrics.mae ? 'linearRegression' : 'randomForest',
    },
    {
      label: 'MSE (Mean Squared Error)',
      description: 'Penalizes larger outliers more heavily. Lower is better.',
      lrVal: formatNumber(linearMetrics.mse),
      rfVal: formatNumber(rfMetrics.mse),
      winner: linearMetrics.mse <= rfMetrics.mse ? 'linearRegression' : 'randomForest',
    },
    {
      label: 'RMSE (Root Mean Squared Error)',
      description: 'Standard deviation of out-of-sample residuals. Lower is better.',
      lrVal: formatCurrency(linearMetrics.rmse),
      rfVal: formatCurrency(rfMetrics.rmse),
      winner: linearMetrics.rmse <= rfMetrics.rmse ? 'linearRegression' : 'randomForest',
    },
    {
      label: 'R² Score (Coefficient of Determination)',
      description: 'Proportion of variance explained by model (1.0 is perfect). Higher is better.',
      lrVal: linearMetrics.r2.toFixed(4),
      rfVal: rfMetrics.r2.toFixed(4),
      winner: linearMetrics.r2 >= rfMetrics.r2 ? 'linearRegression' : 'randomForest',
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
      {/* Header */}
      <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" />
            Model Benchmark Comparison (Chronological 20% Test Set)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Strict out-of-sample evaluation preserving real-world chronological sequence
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Primary Selection: {isRfBest ? 'Random Forest Regression' : 'Linear Regression'}
          </span>
        </div>
      </div>

      {/* Comparison Table */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
              <th className="py-3 px-4">Evaluation Metric</th>
              <th className="py-3 px-4 text-right">
                Linear Regression (OLS + Ridge)
              </th>
              <th className="py-3 px-4 text-right">
                Random Forest (Ensemble)
              </th>
              <th className="py-3 px-4 text-center">Performance Leader</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {rows.map((row, idx) => {
              const isRfWinning = row.winner === 'randomForest';
              const isLrWinning = row.winner === 'linearRegression';
              return (
                <tr key={idx} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{row.label}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{row.description}</div>
                  </td>
                  <td
                    className={`py-3 px-4 text-right font-mono text-sm ${
                      isLrWinning ? 'font-bold text-emerald-600' : 'text-slate-600'
                    }`}
                  >
                    {row.lrVal}
                  </td>
                  <td
                    className={`py-3 px-4 text-right font-mono text-sm ${
                      isRfWinning ? 'font-bold text-emerald-600' : 'text-slate-600'
                    }`}
                  >
                    {row.rfVal}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${
                        row.winner === 'randomForest'
                          ? 'bg-purple-50 text-purple-700 border-purple-200'
                          : 'bg-blue-50 text-blue-700 border-blue-200'
                      }`}
                    >
                      {row.winner === 'randomForest' ? 'Random Forest' : 'Linear Regression'}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 text-xs text-slate-500 flex items-start gap-2">
        <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p>
          Models were trained on the chronological first 80% of sales history and evaluated strictly on the succeeding 20% unseen test window. Random Forest effectively captures nonlinear interactions between discounts, customer spikes, and promotional momentum.
        </p>
      </div>
    </div>
  );
};
