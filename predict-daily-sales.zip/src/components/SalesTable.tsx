import React, { useState, useMemo } from 'react';
import {
  Search,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Filter,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { CleanSalesRecord } from '../types';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';
import { SalesDetailsModal } from './SalesDetailsModal';

interface SalesTableProps {
  records: CleanSalesRecord[];
  categories: string[];
  seasons: string[];
}

type SortKey = 'date' | 'product_category' | 'quantity' | 'price' | 'previous_sales' | 'customers' | 'sales';

export const SalesTable: React.FC<SalesTableProps> = ({
  records,
  categories,
  seasons,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [seasonFilter, setSeasonFilter] = useState('all');
  const [promoFilter, setPromoFilter] = useState('all');
  const [holidayFilter, setHolidayFilter] = useState('all');

  const [sortKey, setSortKey] = useState<SortKey>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const [selectedRecord, setSelectedRecord] = useState<CleanSalesRecord | null>(null);

  // Filtering
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      // Search
      if (searchTerm) {
        const q = searchTerm.toLowerCase().trim();
        const matchId = r.sales_id.toLowerCase().includes(q);
        const matchDate = r.date.toLowerCase().includes(q);
        const matchCat = r.product_category.toLowerCase().includes(q);
        if (!matchId && !matchDate && !matchCat) return false;
      }

      // Category
      if (categoryFilter !== 'all' && r.product_category !== categoryFilter) {
        return false;
      }

      // Season
      if (seasonFilter !== 'all' && r.season !== seasonFilter) {
        return false;
      }

      // Promotion
      if (promoFilter === 'yes' && !r.promotion) return false;
      if (promoFilter === 'no' && r.promotion) return false;

      // Holiday
      if (holidayFilter === 'yes' && !r.holiday) return false;
      if (holidayFilter === 'no' && r.holiday) return false;

      return true;
    });
  }, [records, searchTerm, categoryFilter, seasonFilter, promoFilter, holidayFilter]);

  // Sorting
  const sortedRecords = useMemo(() => {
    const list = [...filteredRecords];
    list.sort((a, b) => {
      let valA: any = a[sortKey];
      let valB: any = b[sortKey];

      if (sortKey === 'date') {
        valA = a.dateObj.getTime();
        valB = b.dateObj.getTime();
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    return list;
  }, [filteredRecords, sortKey, sortOrder]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(sortedRecords.length / pageSize));
  const startIndex = (currentPage - 1) * pageSize;
  const pageRecords = sortedRecords.slice(startIndex, startIndex + pageSize);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('desc');
    }
  };

  const getSortIcon = (key: SortKey) => {
    return (
      <ArrowUpDown
        className={`w-3.5 h-3.5 inline ml-1 transition-opacity ${
          sortKey === key ? 'opacity-100 text-slate-900 font-bold' : 'opacity-40'
        }`}
      />
    );
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
      {/* Search & Filter Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">
              Sales Explorer
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Showing {filteredRecords.length} of {records.length} total daily business records
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search ID, date, category..."
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 font-medium mr-1">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <span>Filters:</span>
          </div>

          {/* Category */}
          <select
            value={categoryFilter}
            onChange={e => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-slate-700"
          >
            <option value="all">All Categories</option>
            {categories.map(c => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          {/* Season */}
          <select
            value={seasonFilter}
            onChange={e => {
              setSeasonFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-slate-700"
          >
            <option value="all">All Seasons</option>
            {seasons.map(s => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Promotion */}
          <select
            value={promoFilter}
            onChange={e => {
              setPromoFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-slate-700"
          >
            <option value="all">Promo: All</option>
            <option value="yes">Promo: Yes</option>
            <option value="no">Promo: No</option>
          </select>

          {/* Holiday */}
          <select
            value={holidayFilter}
            onChange={e => {
              setHolidayFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-slate-700"
          >
            <option value="all">Holiday: All</option>
            <option value="yes">Holiday: Yes</option>
            <option value="no">Holiday: No</option>
          </select>

          {(categoryFilter !== 'all' ||
            seasonFilter !== 'all' ||
            promoFilter !== 'all' ||
            holidayFilter !== 'all' ||
            searchTerm) && (
            <button
              onClick={() => {
                setCategoryFilter('all');
                setSeasonFilter('all');
                setPromoFilter('all');
                setHolidayFilter('all');
                setSearchTerm('');
                setCurrentPage(1);
              }}
              className="text-emerald-700 hover:text-emerald-800 font-semibold underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Internal scrollable table wrapper */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 select-none">
              <th className="py-2.5 px-4 font-semibold">Sales ID</th>
              <th
                onClick={() => handleSort('date')}
                className="py-2.5 px-4 font-semibold cursor-pointer hover:bg-slate-100"
              >
                Date {getSortIcon('date')}
              </th>
              <th
                onClick={() => handleSort('product_category')}
                className="py-2.5 px-4 font-semibold cursor-pointer hover:bg-slate-100"
              >
                Category {getSortIcon('product_category')}
              </th>
              <th
                onClick={() => handleSort('quantity')}
                className="py-2.5 px-4 font-semibold text-right cursor-pointer hover:bg-slate-100"
              >
                Quantity {getSortIcon('quantity')}
              </th>
              <th
                onClick={() => handleSort('price')}
                className="py-2.5 px-4 font-semibold text-right cursor-pointer hover:bg-slate-100"
              >
                Price {getSortIcon('price')}
              </th>
              <th
                onClick={() => handleSort('previous_sales')}
                className="py-2.5 px-4 font-semibold text-right cursor-pointer hover:bg-slate-100"
              >
                Prev Sales {getSortIcon('previous_sales')}
              </th>
              <th className="py-2.5 px-4 font-semibold text-center">Promo</th>
              <th className="py-2.5 px-4 font-semibold text-center">Holiday</th>
              <th
                onClick={() => handleSort('customers')}
                className="py-2.5 px-4 font-semibold text-right cursor-pointer hover:bg-slate-100"
              >
                Customers {getSortIcon('customers')}
              </th>
              <th className="py-2.5 px-4 font-semibold">Season</th>
              <th
                onClick={() => handleSort('sales')}
                className="py-2.5 px-4 font-semibold text-right cursor-pointer hover:bg-slate-100"
              >
                Sales {getSortIcon('sales')}
              </th>
              <th className="py-2.5 px-4 text-center font-semibold">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {pageRecords.length === 0 ? (
              <tr>
                <td colSpan={12} className="py-8 text-center text-slate-400">
                  No sales records matched your filter criteria.
                </td>
              </tr>
            ) : (
              pageRecords.map(row => (
                <tr
                  key={row.sales_id}
                  onClick={() => setSelectedRecord(row)}
                  className="hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <td className="py-2.5 px-4 font-mono font-medium text-slate-900">
                    {row.sales_id}
                  </td>
                  <td className="py-2.5 px-4 font-medium text-slate-800">{row.date}</td>
                  <td className="py-2.5 px-4">{row.product_category}</td>
                  <td className="py-2.5 px-4 text-right">{formatNumber(row.quantity)}</td>
                  <td className="py-2.5 px-4 text-right">{formatCurrency(row.price)}</td>
                  <td className="py-2.5 px-4 text-right text-slate-500">
                    {formatCurrency(row.previous_sales)}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {row.promotion ? (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                        Yes
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {row.holiday ? (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-800">
                        Yes
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-4 text-right">{formatNumber(row.customers)}</td>
                  <td className="py-2.5 px-4">{row.season}</td>
                  <td className="py-2.5 px-4 text-right font-bold text-slate-900">
                    {formatCurrency(row.sales)}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        setSelectedRecord(row);
                      }}
                      className="p-1 rounded hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition-colors"
                      title="View Details"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            value={pageSize}
            onChange={e => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-slate-700"
          >
            <option value={10}>10</option>
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span className="ml-2">
            Showing {filteredRecords.length > 0 ? startIndex + 1 : 0} to{' '}
            {Math.min(filteredRecords.length, startIndex + pageSize)} of {filteredRecords.length}
          </span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="font-semibold text-slate-700 px-2">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Details Modal */}
      {selectedRecord && (
        <SalesDetailsModal
          record={selectedRecord}
          onClose={() => setSelectedRecord(null)}
        />
      )}
    </div>
  );
};
