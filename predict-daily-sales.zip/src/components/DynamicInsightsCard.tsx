import React from 'react';
import { Sparkles, TrendingUp, Award, Layers, Target } from 'lucide-react';
import { DynamicInsight } from '../utils/insights';

interface DynamicInsightsCardProps {
  insights: DynamicInsight[];
}

export const DynamicInsightsCard: React.FC<DynamicInsightsCardProps> = ({ insights }) => {
  const getIcon = (category: DynamicInsight['category']) => {
    switch (category) {
      case 'overview':
        return Layers;
      case 'promotion':
        return Target;
      case 'performance':
        return Award;
      case 'trend':
        return TrendingUp;
      case 'feature':
      default:
        return Sparkles;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
      <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Dynamic Machine-Generated Business Insights
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Computed live from dataset distributions, regression metrics, and time-series patterns
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {insights.map(item => {
          const Icon = getIcon(item.category);
          return (
            <div
              key={item.id}
              className="p-3.5 rounded-lg bg-slate-50/70 border border-slate-200/70 hover:border-slate-300 transition-colors flex items-start gap-3"
            >
              <div className="p-2 rounded-md bg-white border border-slate-200 text-slate-700 shrink-0 mt-0.5">
                <Icon className="w-4 h-4 text-emerald-600" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <h4 className="text-xs font-bold text-slate-900 truncate">
                    {item.title}
                  </h4>
                  {item.badge && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200/80 text-slate-700 shrink-0">
                      {item.badge}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
