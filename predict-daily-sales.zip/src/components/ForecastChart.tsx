import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { CleanSalesRecord, ForecastDayResult } from '../types';
import { formatCurrency } from '../utils/predictionUtils';

interface ForecastChartProps {
  historicalRecords: CleanSalesRecord[];
  forecasts: ForecastDayResult[];
}

export const ForecastChart: React.FC<ForecastChartProps> = ({
  historicalRecords,
  forecasts,
}) => {
  // Take last 30 historical records to show seamless bridge into the forecast horizon
  const recentHistorical = historicalRecords.slice(-30);

  // Combine into unified chart series:
  // For historical points: historicalSales exists, forecastSales is null
  // For the transition point (last historical): both historicalSales and forecastSales can link, or bridge
  // For forecast points: historicalSales is null, forecastSales exists, lowerEstimate and upperEstimate exist
  const data: Array<{
    date: string;
    historicalSales?: number | null;
    forecastSales?: number | null;
    lowerBound?: number | null;
    upperBound?: number | null;
    isForecast?: boolean;
  }> = [];

  for (const h of recentHistorical) {
    data.push({
      date: h.date,
      historicalSales: h.sales,
      forecastSales: null,
      lowerBound: null,
      upperBound: null,
      isForecast: false,
    });
  }

  // Anchor bridge
  if (recentHistorical.length > 0 && forecasts.length > 0) {
    const lastH = recentHistorical[recentHistorical.length - 1];
    data[data.length - 1].forecastSales = lastH.sales;
  }

  for (const f of forecasts) {
    data.push({
      date: f.date,
      historicalSales: null,
      forecastSales: f.predictedSales,
      lowerBound: f.lowerEstimate,
      upperBound: f.upperEstimate,
      isForecast: true,
    });
  }

  const dividerDate = recentHistorical.length > 0 ? recentHistorical[recentHistorical.length - 1].date : '';

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
          <defs>
            <linearGradient id="forecastAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0.03} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
          />
          <Tooltip
            content={({ active, payload, label }) => {
              if (active && payload && payload.length) {
                const item = payload[0]?.payload;
                return (
                  <div className="bg-slate-900 text-white p-3 rounded-lg text-xs shadow-lg border border-slate-800 space-y-1">
                    <div className="font-semibold text-slate-300 border-b border-slate-800 pb-1 flex items-center justify-between gap-3">
                      <span>{label}</span>
                      <span className={item.isForecast ? 'text-emerald-400 font-bold' : 'text-blue-400'}>
                        {item.isForecast ? 'Forecast Day' : 'Historical Day'}
                      </span>
                    </div>
                    {item.historicalSales !== null && item.historicalSales !== undefined && (
                      <div className="text-blue-300 flex justify-between gap-4">
                        <span>Historical Sales:</span>
                        <span className="font-mono font-bold">{formatCurrency(item.historicalSales)}</span>
                      </div>
                    )}
                    {item.forecastSales !== null && item.forecastSales !== undefined && (
                      <>
                        <div className="text-emerald-400 flex justify-between gap-4">
                          <span>Predicted Sales:</span>
                          <span className="font-mono font-bold">{formatCurrency(item.forecastSales)}</span>
                        </div>
                        {item.lowerBound && item.upperBound && (
                          <div className="text-slate-400 text-[11px] flex justify-between gap-4">
                            <span>Confidence Interval:</span>
                            <span className="font-mono">
                              {formatCurrency(item.lowerBound)} – {formatCurrency(item.upperBound)}
                            </span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              }
              return null;
            }}
          />
          <Legend
            verticalAlign="top"
            align="right"
            wrapperStyle={{ paddingBottom: '10px', fontSize: '12px' }}
          />

          {dividerDate && (
            <ReferenceLine
              x={dividerDate}
              stroke="#64748b"
              strokeDasharray="4 4"
              label={{
                value: 'Forecast Transition',
                position: 'top',
                fill: '#64748b',
                fontSize: 10,
              }}
            />
          )}

          {/* Historical Series (Blue) */}
          <Line
            type="monotone"
            dataKey="historicalSales"
            name="Historical Sales"
            stroke="#2563eb"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4, stroke: '#2563eb', strokeWidth: 2 }}
          />

          {/* Forecasted Confidence Interval Area */}
          <Area
            type="monotone"
            dataKey="upperBound"
            stroke="transparent"
            fill="url(#forecastAreaGrad)"
            name="Expected Range"
          />

          {/* Forecasted Series (Emerald Dash) */}
          <Line
            type="monotone"
            dataKey="forecastSales"
            name="ML Forecast"
            stroke="#10b981"
            strokeWidth={2.5}
            strokeDasharray="4 4"
            dot={{ r: 3, fill: '#10b981' }}
            activeDot={{ r: 5, stroke: '#10b981', strokeWidth: 2 }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
