import React, { useState } from 'react';
import { Sparkles, Calendar, Tag, DollarSign, Users, Package, Flame, AlertCircle } from 'lucide-react';
import { PredictionInput, TrainedModelSystem } from '../types';

interface SalesPredictionFormProps {
  categories: string[];
  seasons: string[];
  lastObservedSales: number;
  lastDateStr: string;
  modelSystem: TrainedModelSystem;
  onPredict: (input: PredictionInput, horizon: number, modelChoice: 'linearRegression' | 'randomForest' | 'auto') => void;
  isPredicting: boolean;
}

export const SalesPredictionForm: React.FC<SalesPredictionFormProps> = ({
  categories,
  seasons,
  lastObservedSales,
  lastDateStr,
  modelSystem,
  onPredict,
  isPredicting,
}) => {
  // Compute default next date after last historical date
  const getNextDate = (baseStr: string) => {
    try {
      const d = new Date(baseStr);
      if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + 1);
        return d.toISOString().split('T')[0];
      }
    } catch {}
    return '2025-09-01';
  };

  const [date, setDate] = useState<string>(getNextDate(lastDateStr));
  const [productCategory, setProductCategory] = useState<string>(categories[0] || 'Electronics');
  const [quantity, setQuantity] = useState<number>(65);
  const [price, setPrice] = useState<number>(85);
  const [previousSales, setPreviousSales] = useState<number>(lastObservedSales || 5500);
  const [customers, setCustomers] = useState<number>(140);
  const [promotion, setPromotion] = useState<boolean>(true);
  const [holiday, setHoliday] = useState<boolean>(false);
  const [season, setSeason] = useState<string>(seasons[0] || 'Fall');
  const [horizon, setHorizon] = useState<number>(7);
  const [modelChoice, setModelChoice] = useState<'auto' | 'randomForest' | 'linearRegression'>('auto');
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!date) {
      setValidationError('Please select a valid prediction date.');
      return;
    }

    if (quantity <= 0 || isNaN(quantity)) {
      setValidationError('Expected quantity must be greater than zero.');
      return;
    }

    if (price <= 0 || isNaN(price)) {
      setValidationError('Product price must be greater than zero.');
      return;
    }

    if (previousSales < 0 || isNaN(previousSales)) {
      setValidationError('Previous sales value must be a non-negative number.');
      return;
    }

    if (customers < 0 || isNaN(customers)) {
      setValidationError('Expected customers must be a non-negative number.');
      return;
    }

    const input: PredictionInput = {
      date,
      product_category: productCategory,
      quantity,
      price,
      previous_sales: previousSales,
      customers,
      promotion,
      holiday,
      season,
    };

    onPredict(input, horizon, modelChoice);
  };

  const applyPreset = (type: 'weekend' | 'midweek' | 'holiday') => {
    if (type === 'weekend') {
      setQuantity(120);
      setPrice(79.9);
      setCustomers(260);
      setPromotion(true);
      setHoliday(false);
      setProductCategory(categories.includes('Apparel') ? 'Apparel' : categories[0]);
    } else if (type === 'midweek') {
      setQuantity(45);
      setPrice(89.0);
      setCustomers(95);
      setPromotion(false);
      setHoliday(false);
      setProductCategory(categories.includes('Electronics') ? 'Electronics' : categories[0]);
    } else if (type === 'holiday') {
      setQuantity(195);
      setPrice(95.0);
      setCustomers(420);
      setPromotion(true);
      setHoliday(true);
      setProductCategory(categories.includes('Home & Kitchen') ? 'Home & Kitchen' : categories[0]);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Prediction Configuration
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Provide expected business inputs for the upcoming trading day to execute inference
          </p>
        </div>

        {/* Quick Scenario Presets */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-medium text-slate-400 mr-1">Presets:</span>
          <button
            type="button"
            onClick={() => applyPreset('weekend')}
            className="px-2.5 py-1 text-xs rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
          >
            Weekend Promo
          </button>
          <button
            type="button"
            onClick={() => applyPreset('midweek')}
            className="px-2.5 py-1 text-xs rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
          >
            Midweek Regular
          </button>
          <button
            type="button"
            onClick={() => applyPreset('holiday')}
            className="px-2.5 py-1 text-xs rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
          >
            Holiday Surge
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Row 1: Date, Product Category, Season */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Prediction Date
            </label>
            <div className="relative">
              <input
                id="input-prediction-date"
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Product Category
            </label>
            <select
              id="input-product-category"
              value={productCategory}
              onChange={e => setProductCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Season
            </label>
            <select
              id="input-season"
              value={season}
              onChange={e => setSeason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            >
              {seasons.map(s => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Row 2: Quantity Expected, Price, Previous Sales, Customers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Quantity Expected (Units)
            </label>
            <input
              id="input-quantity"
              type="number"
              min="1"
              max="5000"
              step="1"
              value={quantity}
              onChange={e => setQuantity(Number(e.target.value))}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Unit Price ($)
            </label>
            <input
              id="input-price"
              type="number"
              min="1"
              step="0.1"
              value={price}
              onChange={e => setPrice(Number(e.target.value))}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Previous Day Sales ($)
            </label>
            <input
              id="input-previous-sales"
              type="number"
              min="0"
              step="10"
              value={previousSales}
              onChange={e => setPreviousSales(Number(e.target.value))}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Expected Customers
            </label>
            <input
              id="input-customers"
              type="number"
              min="1"
              step="1"
              value={customers}
              onChange={e => setCustomers(Number(e.target.value))}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Row 3: Promotion toggle, Holiday toggle, Model selector, Horizon */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-50 border border-slate-200/70">
          {/* Promotion Switch */}
          <div className="flex items-center justify-between">
            <div>
              <span className="block text-xs font-semibold text-slate-800">
                Promotional Day
              </span>
              <span className="text-[11px] text-slate-500">
                Marketing discount/campaign
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPromotion(!promotion)}
              className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                promotion ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs transition duration-200 ease-in-out ${
                  promotion ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Holiday Switch */}
          <div className="flex items-center justify-between">
            <div>
              <span className="block text-xs font-semibold text-slate-800">
                Public Holiday
              </span>
              <span className="text-[11px] text-slate-500">
                Recognized calendar holiday
              </span>
            </div>
            <button
              type="button"
              onClick={() => setHoliday(!holiday)}
              className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                holiday ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs transition duration-200 ease-in-out ${
                  holiday ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Model Architecture Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Regression Model
            </label>
            <select
              id="select-model-choice"
              value={modelChoice}
              onChange={e => setModelChoice(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-md text-xs font-medium text-slate-800"
            >
              <option value="auto">
                Auto (Best: {modelSystem.bestModelType === 'randomForest' ? 'Random Forest' : 'Linear Reg.'})
              </option>
              <option value="randomForest">Random Forest Regression</option>
              <option value="linearRegression">Linear Regression</option>
            </select>
          </div>

          {/* Forecast Horizon */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Forecast Horizon
            </label>
            <div className="grid grid-cols-4 gap-1">
              {[1, 7, 14, 30].map(d => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setHorizon(d)}
                  className={`py-1 text-xs font-semibold rounded transition-colors ${
                    horizon === d
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {d}D
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Validation Error */}
        {validationError && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            id="btn-predict-daily-sales"
            type="submit"
            disabled={isPredicting}
            className="w-full sm:w-auto px-6 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-sm font-bold shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isPredicting ? 'Executing Model Inference...' : 'Predict Daily Sales'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
