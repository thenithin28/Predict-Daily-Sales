import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  BarChart3,
  BrainCircuit,
  FileSpreadsheet,
  Database,
  Calendar,
  Sparkles,
  X,
} from 'lucide-react';

export type NavTab = 'dashboard' | 'predictor' | 'analysis' | 'performance';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpen: boolean;
  onClose: () => void;
  totalRecords: number;
  bestModelName: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpen,
  onClose,
  totalRecords,
  bestModelName,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.ElementType; tag?: string }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'predictor',
      label: 'Daily Sales Predictor',
      icon: TrendingUp,
      tag: 'ML',
    },
    {
      id: 'analysis',
      label: 'Sales Analysis',
      icon: BarChart3,
    },
    {
      id: 'performance',
      label: 'Model Performance',
      icon: BrainCircuit,
      tag: '2 Models',
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-slate-900 text-slate-200 border-r border-slate-800/80 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-6 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-white text-base tracking-tight block leading-tight">
                Predict Daily Sales
              </span>
              <span className="text-[11px] text-slate-400 font-medium">
                Machine Learning Studio
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dataset Status Banner */}
        <div className="p-4 mx-4 mt-4 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="flex items-center gap-1.5 font-medium">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              Dataset Status
            </span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Active
            </span>
          </div>
          <div className="text-white font-medium text-xs">
            {totalRecords > 0 ? `${totalRecords} Historical Records` : 'Loading...'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            Best Model: {bestModelName || 'Evaluated'}
          </div>
        </div>

        {/* Navigation List */}
        <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
            Navigation
          </div>

          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => {
                  onSelectTab(item.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-emerald-500 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.tag && (
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {item.tag}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Footer Info */}
        <div className="p-4 border-t border-slate-800 text-xs text-slate-400 space-y-2">
          <div className="flex items-center justify-between">
            <span>ML Runtime</span>
            <span className="text-emerald-400 font-mono text-[11px]">Browser JS/TS</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Algorithms</span>
            <span className="text-slate-300 text-[11px]">Linear &amp; RF</span>
          </div>
          <div className="text-[10px] text-slate-500 pt-1 text-center">
            No server or external API required
          </div>
        </div>
      </aside>
    </>
  );
};
