import React from 'react';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  id?: string;
  className?: string;
  footer?: React.ReactNode;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  title,
  subtitle,
  actions,
  children,
  id,
  className = '',
  footer,
}) => {
  return (
    <div
      id={id}
      className={`bg-white rounded-xl border border-slate-200/80 shadow-xs flex flex-col p-5 overflow-hidden ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-800 tracking-tight">{title}</h3>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">{actions}</div>}
      </div>

      <div className="flex-1 w-full min-w-0 min-h-[260px]">{children}</div>

      {footer && <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">{footer}</div>}
    </div>
  );
};
