import { FeatureImportanceItem } from '../types';

export interface LinearRegressionModel {
  weights: number[]; // first is bias, followed by D weights
  means: number[];
  stds: number[];
  featureNames: string[];
  featureImportance: FeatureImportanceItem[];
}

/**
 * Solves A * x = B using Gauss-Jordan elimination with partial pivoting
 */
function solveLinearSystem(A: number[][], b: number[]): number[] {
  const n = A.length;
  // Create augmented matrix
  const M: number[][] = [];
  for (let i = 0; i < n; i++) {
    M.push([...A[i], b[i]]);
  }

  for (let col = 0; col < n; col++) {
    // Pivot selection
    let maxRow = col;
    let maxVal = Math.abs(M[col][col]);
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(M[r][col]) > maxVal) {
        maxVal = Math.abs(M[r][col]);
        maxRow = r;
      }
    }

    if (maxVal < 1e-12) {
      // Degenerate column, regularize diagonal
      M[col][col] += 1e-5;
    }

    // Swap rows
    if (maxRow !== col) {
      const temp = M[col];
      M[col] = M[maxRow];
      M[maxRow] = temp;
    }

    // Normalize pivot row
    const pivot = M[col][col];
    for (let c = col; c <= n; c++) {
      M[col][c] /= pivot;
    }

    // Eliminate other rows
    for (let r = 0; r < n; r++) {
      if (r !== col) {
        const factor = M[r][col];
        for (let c = col; c <= n; c++) {
          M[r][c] -= factor * M[col][c];
        }
      }
    }
  }

  return M.map(row => row[n]);
}

export function trainLinearRegression(
  X: number[][],
  y: number[],
  featureNames: string[],
  ridgeLambda = 0.01
): LinearRegressionModel {
  const N = X.length;
  const D = featureNames.length;

  // 1. Calculate means and stds for normalization
  const means: number[] = new Array(D).fill(0);
  const stds: number[] = new Array(D).fill(0);

  for (let j = 0; j < D; j++) {
    let sum = 0;
    for (let i = 0; i < N; i++) {
      sum += X[i][j];
    }
    means[j] = sum / N;

    let varSum = 0;
    for (let i = 0; i < N; i++) {
      const diff = X[i][j] - means[j];
      varSum += diff * diff;
    }
    const std = Math.sqrt(varSum / N);
    stds[j] = std > 1e-6 ? std : 1.0;
  }

  // 2. Build normalized X matrix with intercept column (size N x (D+1))
  const X_aug: number[][] = [];
  for (let i = 0; i < N; i++) {
    const row = [1.0];
    for (let j = 0; j < D; j++) {
      row.push((X[i][j] - means[j]) / stds[j]);
    }
    X_aug.push(row);
  }

  const P = D + 1; // number of parameters

  // 3. Compute XtX = X_aug^T * X_aug and Xty = X_aug^T * y
  const XtX: number[][] = Array.from({ length: P }, () => new Array(P).fill(0));
  const Xty: number[] = new Array(P).fill(0);

  for (let i = 0; i < N; i++) {
    const xi = X_aug[i];
    const yi = y[i];

    for (let r = 0; r < P; r++) {
      const xir = xi[r];
      Xty[r] += xir * yi;
      for (let c = r; c < P; c++) {
        XtX[r][c] += xir * xi[c];
      }
    }
  }

  // Symmetrize XtX
  for (let r = 0; r < P; r++) {
    for (let c = 0; c < r; c++) {
      XtX[r][c] = XtX[c][r];
    }
  }

  // Add Ridge Regularization (lambda * I) to non-bias terms
  for (let j = 1; j < P; j++) {
    XtX[j][j] += ridgeLambda * N;
  }

  // 4. Solve for weights w = (XtX)^-1 Xty
  const weights = solveLinearSystem(XtX, Xty);

  // 5. Compute feature importances based on standardized coefficient magnitude
  const importanceItems: FeatureImportanceItem[] = [];
  let totalAbsWeight = 0;

  for (let j = 0; j < D; j++) {
    const absW = Math.abs(weights[j + 1]);
    totalAbsWeight += absW;
  }

  const safeTotal = totalAbsWeight > 0 ? totalAbsWeight : 1.0;
  for (let j = 0; j < D; j++) {
    const rawVal = Math.abs(weights[j + 1]);
    importanceItems.push({
      feature: featureNames[j],
      importance: Number(rawVal.toFixed(4)),
      normalizedImportance: Number(((rawVal / safeTotal) * 100).toFixed(2)),
    });
  }

  importanceItems.sort((a, b) => b.importance - a.importance);

  return {
    weights,
    means,
    stds,
    featureNames,
    featureImportance: importanceItems,
  };
}

export function predictLinearRegression(
  model: LinearRegressionModel,
  features: number[]
): number {
  const { weights, means, stds } = model;
  let pred = weights[0]; // Intercept

  for (let j = 0; j < features.length; j++) {
    const normalized = (features[j] - means[j]) / stds[j];
    pred += weights[j + 1] * normalized;
  }

  return Math.max(0, pred);
}
