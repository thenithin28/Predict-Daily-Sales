import {
  CleanSalesRecord,
  FeatureRecord,
  PredictionInput,
  TrainedModelSystem,
  ModelMetrics,
} from '../types';
import { extractDateFeatures } from './dateFeatures';
import { computeLagFeaturesForRecord } from './lagFeatures';
import { computeRollingFeaturesForRecord } from './rollingFeatures';
import {
  buildEncoder,
  extractFeatureVectorFromRecord,
  extractFeatureVectorFromInput,
} from './encoding';
import {
  trainLinearRegression,
  predictLinearRegression,
  LinearRegressionModel,
} from './linearRegression';
import {
  trainRandomForest,
  predictRandomForest,
  RandomForestModel,
} from './randomForest';
import { evaluatePredictions } from '../utils/metrics';

export function prepareFeatureRecords(records: CleanSalesRecord[]): FeatureRecord[] {
  const avgSales = records.length > 0 ? records.reduce((s, r) => s + r.sales, 0) / records.length : 5000;

  return records.map((rec, idx) => {
    const dateFeatures = extractDateFeatures(rec.dateObj);
    const lag = computeLagFeaturesForRecord(records, idx, avgSales);
    const rolling = computeRollingFeaturesForRecord(records, idx, avgSales);
    const revenue_potential = rec.quantity * rec.price;

    return {
      ...rec,
      ...dateFeatures,
      ...lag,
      ...rolling,
      revenue_potential,
    };
  });
}

export function trainModelsPipeline(cleanRecords: CleanSalesRecord[]): TrainedModelSystem {
  if (cleanRecords.length < 20) {
    throw new Error('Insufficient sales records to train models. At least 20 records required.');
  }

  // 1. Build FeatureRecords
  const featureRecords = prepareFeatureRecords(cleanRecords);

  // 2. Build categorical encoder
  const encoder = buildEncoder(featureRecords);

  // 3. Build Full Matrix X and Target y
  const X_all: number[][] = [];
  const y_all: number[] = [];
  const dates_all: string[] = [];

  for (const rec of featureRecords) {
    X_all.push(extractFeatureVectorFromRecord(rec, encoder));
    y_all.push(rec.sales);
    dates_all.push(rec.date);
  }

  // 4. Chronological 80/20 train/test split
  const totalCount = X_all.length;
  const trainCount = Math.floor(totalCount * 0.8);
  const testCount = totalCount - trainCount;

  const X_train = X_all.slice(0, trainCount);
  const y_train = y_all.slice(0, trainCount);

  const X_test = X_all.slice(trainCount);
  const y_test = y_all.slice(trainCount);
  const test_dates = dates_all.slice(trainCount);

  // 5. Train Linear Regression
  const lrModel: LinearRegressionModel = trainLinearRegression(
    X_train,
    y_train,
    encoder.featureNames,
    0.05
  );
  const lrTestPreds = X_test.map(x => predictLinearRegression(lrModel, x));
  const lrEval = evaluatePredictions(y_test, lrTestPreds, test_dates);

  const lrMetrics: ModelMetrics = {
    name: 'Linear Regression',
    modelType: 'linearRegression',
    mae: lrEval.mae,
    mse: lrEval.mse,
    rmse: lrEval.rmse,
    r2: lrEval.r2,
    meanResidual: lrEval.meanResidual,
    maxPositiveResidual: lrEval.maxPositiveResidual,
    maxNegativeResidual: lrEval.maxNegativeResidual,
    predictions: lrEval.predictions,
    featureImportance: lrModel.featureImportance,
  };

  // 6. Train Random Forest Regression
  const rfModel: RandomForestModel = trainRandomForest(
    X_train,
    y_train,
    encoder.featureNames,
    25, // 25 trees
    7,  // max depth
    4   // min sample split
  );
  const rfTestPreds = X_test.map(x => predictRandomForest(rfModel, x));
  const rfEval = evaluatePredictions(y_test, rfTestPreds, test_dates);

  const rfMetrics: ModelMetrics = {
    name: 'Random Forest Regression',
    modelType: 'randomForest',
    mae: rfEval.mae,
    mse: rfEval.mse,
    rmse: rfEval.rmse,
    r2: rfEval.r2,
    meanResidual: rfEval.meanResidual,
    maxPositiveResidual: rfEval.maxPositiveResidual,
    maxNegativeResidual: rfEval.maxNegativeResidual,
    predictions: rfEval.predictions,
    featureImportance: rfModel.featureImportance,
  };

  // 7. Select best model based on RMSE & R2
  const bestModelType: 'linearRegression' | 'randomForest' =
    rfMetrics.rmse <= lrMetrics.rmse ? 'randomForest' : 'linearRegression';

  const historicalAverageDailySales = Math.round(
    y_all.reduce((a, b) => a + b, 0) / y_all.length
  );

  // 8. Inference function
  const predict = (
    input: PredictionInput,
    modelChoice?: 'linearRegression' | 'randomForest'
  ) => {
    const selectedType = modelChoice || bestModelType;
    const activeMetrics = selectedType === 'linearRegression' ? lrMetrics : rfMetrics;

    // Date features for user's input date
    const dateFeats = extractDateFeatures(input.date);

    // Dynamic lag & rolling estimation from historical dataset
    // We compute moving averages from recent historical observations
    const recentN = cleanRecords.length;
    const lag_1 = input.previous_sales > 0 ? input.previous_sales : (recentN > 0 ? cleanRecords[recentN - 1].sales : historicalAverageDailySales);

    // Lag 7 and Lag 30 from past records
    const idx7 = Math.max(0, recentN - 7);
    const lag_7 = recentN > 0 ? cleanRecords[idx7].sales : historicalAverageDailySales;

    const idx30 = Math.max(0, recentN - 30);
    const lag_30 = recentN > 0 ? cleanRecords[idx30].sales : historicalAverageDailySales;

    // Rolling averages
    const roll_7 = cleanRecords.slice(-7).reduce((s, r) => s + r.sales, 0) / Math.min(7, recentN || 1);
    const roll_14 = cleanRecords.slice(-14).reduce((s, r) => s + r.sales, 0) / Math.min(14, recentN || 1);
    const roll_30 = cleanRecords.slice(-30).reduce((s, r) => s + r.sales, 0) / Math.min(30, recentN || 1);

    const engineered = {
      month: dateFeats.month,
      day: dateFeats.day,
      dayOfWeek: dateFeats.dayOfWeek,
      isWeekend: dateFeats.isWeekend,
      quarter: dateFeats.quarter,
      lag_1,
      lag_7,
      lag_30,
      roll_7,
      roll_14,
      roll_30,
    };

    const xVector = extractFeatureVectorFromInput(input, encoder, engineered);

    let rawPredicted = 0;
    if (selectedType === 'linearRegression') {
      rawPredicted = predictLinearRegression(lrModel, xVector);
    } else {
      rawPredicted = predictRandomForest(rfModel, xVector);
    }

    const predictedSales = Math.max(100, Math.round(rawPredicted));

    // Calculate prediction interval derived from actual test set error
    // Margin based on 1.25 * test RMSE or 1.5 * MAE
    const errorMargin = Math.round(activeMetrics.rmse > 0 ? activeMetrics.rmse * 1.25 : activeMetrics.mae * 1.5);
    const lowerEstimate = Math.max(0, predictedSales - errorMargin);
    const upperEstimate = predictedSales + errorMargin;

    return {
      predictedSales,
      lowerEstimate,
      upperEstimate,
      margin: errorMargin,
      modelUsed: selectedType === 'linearRegression' ? 'Linear Regression' : 'Random Forest Regression',
    };
  };

  return {
    linearRegression: lrMetrics,
    randomForest: rfMetrics,
    bestModelType,
    featureNames: encoder.featureNames,
    trainCount,
    testCount,
    categories: encoder.categories,
    seasons: encoder.seasons,
    historicalAverageDailySales,
    trainedAt: new Date().toISOString(),
    predict,
  };
}
