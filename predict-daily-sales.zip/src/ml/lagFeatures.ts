import { CleanSalesRecord } from '../types';

export interface LagFeatures {
  lag_1: number;
  lag_7: number;
  lag_30: number;
}

/**
 * Computes lag sales strictly using prior chronological observations.
 * For the record at index i, only indices < i are consulted.
 */
export function computeLagFeaturesForRecord(
  records: CleanSalesRecord[],
  currentIndex: number,
  fallbackSales: number
): LagFeatures {
  if (currentIndex <= 0) {
    const defaultVal = records.length > 0 ? records[0].previous_sales || fallbackSales : fallbackSales;
    return {
      lag_1: defaultVal,
      lag_7: defaultVal,
      lag_30: defaultVal,
    };
  }

  // lag_1 is the sales of the immediately preceding record (index i - 1)
  const lag_1 = records[currentIndex - 1].sales;

  // lag_7: 7 records prior, or earliest available prior record
  const idx7 = Math.max(0, currentIndex - 7);
  const lag_7 = records[idx7].sales;

  // lag_30: 30 records prior, or earliest available prior record
  const idx30 = Math.max(0, currentIndex - 30);
  const lag_30 = records[idx30].sales;

  return {
    lag_1,
    lag_7,
    lag_30,
  };
}
