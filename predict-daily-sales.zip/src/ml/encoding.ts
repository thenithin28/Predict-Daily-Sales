import { FeatureRecord, PredictionInput } from '../types';

export interface CategoryEncoder {
  categories: string[];
  seasons: string[];
  featureNames: string[];
}

export function buildEncoder(records: FeatureRecord[]): CategoryEncoder {
  const catSet = new Set<string>();
  const seasonSet = new Set<string>();

  for (const r of records) {
    if (r.product_category) catSet.add(r.product_category);
    if (r.season) seasonSet.add(r.season);
  }

  const categories = Array.from(catSet).sort();
  const seasons = Array.from(seasonSet).sort();

  const numericFeatures = [
    'quantity',
    'price',
    'revenue_potential',
    'previous_sales',
    'customers',
    'promotion',
    'holiday',
    'month',
    'day',
    'dayOfWeek',
    'isWeekend',
    'quarter',
    'lag_1',
    'lag_7',
    'lag_30',
    'roll_7',
    'roll_14',
    'roll_30',
  ];

  const catFeatures = categories.map(c => `cat_${c}`);
  const seasonFeatures = seasons.map(s => `season_${s}`);

  const featureNames = [...numericFeatures, ...catFeatures, ...seasonFeatures];

  return {
    categories,
    seasons,
    featureNames,
  };
}

export function extractFeatureVectorFromRecord(
  record: FeatureRecord,
  encoder: CategoryEncoder
): number[] {
  const values: number[] = [
    record.quantity,
    record.price,
    record.revenue_potential,
    record.previous_sales,
    record.customers,
    record.promotion ? 1 : 0,
    record.holiday ? 1 : 0,
    record.month,
    record.day,
    record.dayOfWeek,
    record.isWeekend,
    record.quarter,
    record.lag_1,
    record.lag_7,
    record.lag_30,
    record.roll_7,
    record.roll_14,
    record.roll_30,
  ];

  // One-hot categories
  for (const cat of encoder.categories) {
    values.push(record.product_category === cat ? 1 : 0);
  }

  // One-hot seasons
  for (const sea of encoder.seasons) {
    values.push(record.season === sea ? 1 : 0);
  }

  return values;
}

export function extractFeatureVectorFromInput(
  input: PredictionInput,
  encoder: CategoryEncoder,
  engineered: {
    month: number;
    day: number;
    dayOfWeek: number;
    isWeekend: number;
    quarter: number;
    lag_1: number;
    lag_7: number;
    lag_30: number;
    roll_7: number;
    roll_14: number;
    roll_30: number;
  }
): number[] {
  const revenue_potential = input.quantity * input.price;

  const values: number[] = [
    input.quantity,
    input.price,
    revenue_potential,
    input.previous_sales,
    input.customers,
    input.promotion ? 1 : 0,
    input.holiday ? 1 : 0,
    engineered.month,
    engineered.day,
    engineered.dayOfWeek,
    engineered.isWeekend,
    engineered.quarter,
    engineered.lag_1,
    engineered.lag_7,
    engineered.lag_30,
    engineered.roll_7,
    engineered.roll_14,
    engineered.roll_30,
  ];

  // One-hot categories
  for (const cat of encoder.categories) {
    values.push(input.product_category === cat ? 1 : 0);
  }

  // One-hot seasons
  for (const sea of encoder.seasons) {
    values.push(input.season === sea ? 1 : 0);
  }

  return values;
}
