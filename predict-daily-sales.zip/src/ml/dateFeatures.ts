export interface DateFeatures {
  year: number;
  month: number;
  day: number;
  dayOfWeek: number; // 0 (Sunday) to 6 (Saturday)
  isWeekend: number; // 1 if Sat/Sun, else 0
  quarter: number;   // 1 to 4
  weekOfYear: number;
}

export function extractDateFeatures(dateInput: Date | string): DateFeatures {
  const dateObj = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth() + 1; // 1 to 12
  const day = dateObj.getDate();
  const dayOfWeek = dateObj.getDay(); // 0 is Sun, 6 is Sat
  const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6) ? 1 : 0;
  const quarter = Math.ceil(month / 3);

  // Calculate week of year
  const firstDayOfYear = new Date(year, 0, 1);
  const pastDaysOfYear = (dateObj.getTime() - firstDayOfYear.getTime()) / 86400000;
  const weekOfYear = Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);

  return {
    year,
    month,
    day,
    dayOfWeek,
    isWeekend,
    quarter,
    weekOfYear,
  };
}
