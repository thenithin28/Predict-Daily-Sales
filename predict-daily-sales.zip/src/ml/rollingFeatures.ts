import { CleanSalesRecord } from '../types';

export interface RollingFeatures {
  roll_7: number;
  roll_14: number;
  roll_30: number;
}

/**
 * Computes moving averages of sales over prior observations only.
 * For the record at index i, window takes records from max(0, i - windowSize) up to i - 1.
 */
export function computeRollingFeaturesForRecord(
  records: CleanSalesRecord[],
  currentIndex: number,
  fallbackSales: number
): RollingFeatures {
  if (currentIndex <= 0) {
    const defaultVal = records.length > 0 ? records[0].previous_sales || fallbackSales : fallbackSales;
    return {
      roll_7: defaultVal,
      roll_14: defaultVal,
      roll_30: defaultVal,
    };
  }

  function getPriorAverage(windowSize: number): number {
    const startIdx = Math.max(0, currentIndex - windowSize);
    const count = currentIndex - startIdx;
    if (count <= 0) return fallbackSales;

    let sum = 0;
    for (let k = startIdx; k < currentIndex; k++) {
      sum += records[k].sales;
    }
    return sum / count;
  }

  return {
    roll_7: getPriorAverage(7),
    roll_14: getPriorAverage(14),
    roll_30: getPriorAverage(30),
  };
}
