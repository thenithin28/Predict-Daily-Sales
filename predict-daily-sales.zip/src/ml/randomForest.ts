import { FeatureImportanceItem } from '../types';

interface TreeNode {
  isLeaf: boolean;
  value: number;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

export interface RandomForestModel {
  trees: TreeNode[];
  featureNames: string[];
  featureImportance: FeatureImportanceItem[];
  treeCount: number;
}

interface SplitResult {
  bestFeature: number;
  bestThreshold: number;
  bestGain: number;
  leftIndices: number[];
  rightIndices: number[];
}

function calculateVariance(y: number[], indices: number[]): number {
  if (indices.length === 0) return 0;
  let sum = 0;
  for (let i = 0; i < indices.length; i++) {
    sum += y[indices[i]];
  }
  const mean = sum / indices.length;
  let sse = 0;
  for (let i = 0; i < indices.length; i++) {
    const d = y[indices[i]] - mean;
    sse += d * d;
  }
  return sse;
}

function buildTree(
  X: number[][],
  y: number[],
  indices: number[],
  currentDepth: number,
  maxDepth: number,
  minSamplesSplit: number,
  featuresPerSplit: number,
  D: number,
  featureImportancesAccumulator: number[]
): TreeNode {
  const n = indices.length;

  // Calculate leaf value (mean)
  let sumY = 0;
  for (let i = 0; i < n; i++) {
    sumY += y[indices[i]];
  }
  const leafValue = sumY / n;

  if (currentDepth >= maxDepth || n < minSamplesSplit) {
    return { isLeaf: true, value: leafValue };
  }

  const parentSSE = calculateVariance(y, indices);
  if (parentSSE < 1e-4) {
    return { isLeaf: true, value: leafValue };
  }

  // Feature subsampling: select random subset of features
  const allFeatureIndices = Array.from({ length: D }, (_, i) => i);
  // Shuffle partially to pick featuresPerSplit
  for (let i = allFeatureIndices.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = allFeatureIndices[i];
    allFeatureIndices[i] = allFeatureIndices[j];
    allFeatureIndices[j] = temp;
  }
  const selectedFeatures = allFeatureIndices.slice(0, featuresPerSplit);

  let bestSplit: SplitResult | null = null;
  let maxGain = 0;

  for (const fIdx of selectedFeatures) {
    // Extract unique values to test thresholds
    const values = indices.map(i => X[i][fIdx]);
    values.sort((a, b) => a - b);

    // Pick candidate percentiles/thresholds to keep tree building snappy & robust
    const step = Math.max(1, Math.floor(values.length / 12));
    for (let v = 0; v < values.length - 1; v += step) {
      const threshold = (values[v] + values[v + 1]) / 2;

      const left: number[] = [];
      const right: number[] = [];

      for (let i = 0; i < n; i++) {
        const idx = indices[i];
        if (X[idx][fIdx] <= threshold) {
          left.push(idx);
        } else {
          right.push(idx);
        }
      }

      if (left.length === 0 || right.length === 0) continue;

      const leftSSE = calculateVariance(y, left);
      const rightSSE = calculateVariance(y, right);
      const gain = parentSSE - (leftSSE + rightSSE);

      if (gain > maxGain) {
        maxGain = gain;
        bestSplit = {
          bestFeature: fIdx,
          bestThreshold: threshold,
          bestGain: gain,
          leftIndices: left,
          rightIndices: right,
        };
      }
    }
  }

  if (!bestSplit || bestSplit.bestGain <= 0) {
    return { isLeaf: true, value: leafValue };
  }

  // Accumulate feature importance (SSE reduction gain)
  featureImportancesAccumulator[bestSplit.bestFeature] += bestSplit.bestGain;

  const leftChild = buildTree(
    X,
    y,
    bestSplit.leftIndices,
    currentDepth + 1,
    maxDepth,
    minSamplesSplit,
    featuresPerSplit,
    D,
    featureImportancesAccumulator
  );

  const rightChild = buildTree(
    X,
    y,
    bestSplit.rightIndices,
    currentDepth + 1,
    maxDepth,
    minSamplesSplit,
    featuresPerSplit,
    D,
    featureImportancesAccumulator
  );

  return {
    isLeaf: false,
    value: leafValue,
    featureIndex: bestSplit.bestFeature,
    threshold: bestSplit.bestThreshold,
    left: leftChild,
    right: rightChild,
  };
}

function predictTree(node: TreeNode, x: number[]): number {
  if (node.isLeaf || node.featureIndex === undefined || node.threshold === undefined) {
    return node.value;
  }

  if (x[node.featureIndex] <= node.threshold) {
    return node.left ? predictTree(node.left, x) : node.value;
  } else {
    return node.right ? predictTree(node.right, x) : node.value;
  }
}

export function trainRandomForest(
  X: number[][],
  y: number[],
  featureNames: string[],
  treeCount = 25,
  maxDepth = 7,
  minSamplesSplit = 4
): RandomForestModel {
  const N = X.length;
  const D = featureNames.length;
  const featuresPerSplit = Math.max(3, Math.min(D, Math.floor(Math.sqrt(D)) + 3));

  const trees: TreeNode[] = [];
  const featureImportancesAccumulator = new Array(D).fill(0);

  for (let t = 0; t < treeCount; t++) {
    // Bootstrap sampling with replacement
    const bootstrapIndices: number[] = new Array(N);
    for (let i = 0; i < N; i++) {
      bootstrapIndices[i] = Math.floor(Math.random() * N);
    }

    const tree = buildTree(
      X,
      y,
      bootstrapIndices,
      0,
      maxDepth,
      minSamplesSplit,
      featuresPerSplit,
      D,
      featureImportancesAccumulator
    );

    trees.push(tree);
  }

  // Calculate normalized feature importance
  const totalImportance = featureImportancesAccumulator.reduce((sum, val) => sum + val, 0);
  const safeTotal = totalImportance > 0 ? totalImportance : 1.0;

  const featureImportanceItems: FeatureImportanceItem[] = featureNames.map((name, idx) => {
    const rawVal = featureImportancesAccumulator[idx];
    return {
      feature: name,
      importance: Number(rawVal.toFixed(2)),
      normalizedImportance: Number(((rawVal / safeTotal) * 100).toFixed(2)),
    };
  });

  featureImportanceItems.sort((a, b) => b.normalizedImportance - a.normalizedImportance);

  return {
    trees,
    featureNames,
    featureImportance: featureImportanceItems,
    treeCount,
  };
}

export function predictRandomForest(model: RandomForestModel, x: number[]): number {
  if (model.trees.length === 0) return 0;

  let sum = 0;
  for (const tree of model.trees) {
    sum += predictTree(tree, x);
  }

  return Math.max(0, sum / model.trees.length);
}
