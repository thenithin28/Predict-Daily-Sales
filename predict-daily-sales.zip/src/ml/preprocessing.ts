import { RawSalesRecord, CleanSalesRecord } from '../types';

export function cleanAndPreprocessSales(rawRows: RawSalesRecord[]): CleanSalesRecord[] {
  // 1. Filter out empty or null rows
  const validRows = rawRows.filter(r => r && r.date && r.sales !== undefined && r.sales !== '');

  // 2. Parse and normalize
  const parsedRecords: { record: CleanSalesRecord; isValid: boolean }[] = validRows.map((row, idx) => {
    const rawDate = String(row.date).trim();
    const dateObj = new Date(rawDate);
    const isValidDate = !isNaN(dateObj.getTime());

    const quantity = Number(row.quantity);
    const price = Number(row.price);
    const prevSales = Number(row.previous_sales);
    const customers = Number(row.customers);
    const sales = Number(row.sales);
    const discount = row.discount !== undefined && row.discount !== '' ? Number(row.discount) : 0;

    const promoStr = String(row.promotion || '').toLowerCase().trim();
    const isPromo = promoStr === 'yes' || promoStr === 'true' || promoStr === '1';

    const holidayStr = String(row.holiday || '').toLowerCase().trim();
    const isHoliday = holidayStr === 'yes' || holidayStr === 'true' || holidayStr === '1';

    const category = String(row.product_category || 'General').trim();
    const season = String(row.season || 'Regular').trim();
    const salesId = row.sales_id ? String(row.sales_id).trim() : `SLS-${String(idx + 1).padStart(4, '0')}`;

    return {
      record: {
        sales_id: salesId,
        date: rawDate,
        dateObj,
        product_category: category,
        quantity: isNaN(quantity) ? -1 : Math.max(0, quantity),
        price: isNaN(price) ? -1 : Math.max(0, price),
        previous_sales: isNaN(prevSales) ? -1 : Math.max(0, prevSales),
        promotion: isPromo,
        holiday: isHoliday,
        customers: isNaN(customers) ? -1 : Math.max(0, customers),
        season: season || 'Regular',
        sales: isNaN(sales) ? -1 : Math.max(0, sales),
        store_id: row.store_id ? String(row.store_id).trim() : undefined,
        discount: isNaN(discount) ? 0 : discount,
      },
      isValid: isValidDate && !isNaN(sales) && sales > 0,
    };
  });

  const cleaned = parsedRecords.filter(p => p.isValid).map(p => p.record);

  // 3. Remove duplicates (by sales_id or exact duplicate date+category)
  const seenKeys = new Set<string>();
  const deduplicated: CleanSalesRecord[] = [];

  for (const item of cleaned) {
    const key = `${item.sales_id}_${item.date}_${item.product_category}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      deduplicated.push(item);
    }
  }

  // 4. Sort chronologically by date ASC
  deduplicated.sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime());

  // 5. Impute missing/invalid values with median
  const validQuantities = deduplicated.map(r => r.quantity).filter(q => q > 0).sort((a, b) => a - b);
  const medianQty = validQuantities.length > 0 ? validQuantities[Math.floor(validQuantities.length / 2)] : 50;

  const validPrices = deduplicated.map(r => r.price).filter(p => p > 0).sort((a, b) => a - b);
  const medianPrice = validPrices.length > 0 ? validPrices[Math.floor(validPrices.length / 2)] : 50;

  const validCustomers = deduplicated.map(r => r.customers).filter(c => c > 0).sort((a, b) => a - b);
  const medianCustomers = validCustomers.length > 0 ? validCustomers[Math.floor(validCustomers.length / 2)] : 100;

  for (let i = 0; i < deduplicated.length; i++) {
    const item = deduplicated[i];
    if (item.quantity <= 0) item.quantity = medianQty;
    if (item.price <= 0) item.price = medianPrice;
    if (item.customers <= 0) item.customers = medianCustomers;
    if (item.previous_sales <= 0) {
      // Prior day sales or median
      item.previous_sales = i > 0 ? deduplicated[i - 1].sales : item.sales;
    }
  }

  return deduplicated;
}
