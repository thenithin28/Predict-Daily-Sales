export interface RawSalesRecord {
  sales_id?: string;
  date: string;
  product_category: string;
  quantity: string | number;
  price: string | number;
  previous_sales: string | number;
  promotion: string;
  holiday: string;
  customers: string | number;
  season: string;
  sales: string | number;
  store_id?: string;
  discount?: string | number;
}

export interface CleanSalesRecord {
  sales_id: string;
  date: string;
  dateObj: Date;
  product_category: string;
  quantity: number;
  price: number;
  previous_sales: number;
  promotion: boolean;
  holiday: boolean;
  customers: number;
  season: string;
  sales: number;
  store_id?: string;
  discount?: number;
}

export interface FeatureRecord extends CleanSalesRecord {
  // Date Features
  year: number;
  month: number;
  day: number;
  dayOfWeek: number; // 0=Sunday..6=Saturday
  isWeekend: number; // 0 or 1
  quarter: number;
  weekOfYear: number;

  // Lag Features (strictly from prior observations)
  lag_1: number;
  lag_7: number;
  lag_30: number;

  // Rolling Averages (strictly from prior observations)
  roll_7: number;
  roll_14: number;
  roll_30: number;

  // Business Feature
  revenue_potential: number; // quantity * price
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number;
  normalizedImportance: number;
}

export interface PredictionPoint {
  index: number;
  date: string;
  actual: number;
  predicted: number;
  residual: number;
}

export interface ModelMetrics {
  name: string;
  modelType: 'linearRegression' | 'randomForest';
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
  meanResidual: number;
  maxPositiveResidual: number;
  maxNegativeResidual: number;
  predictions: PredictionPoint[];
  featureImportance: FeatureImportanceItem[];
}

export interface TrainedModelSystem {
  linearRegression: ModelMetrics;
  randomForest: ModelMetrics;
  bestModelType: 'linearRegression' | 'randomForest';
  featureNames: string[];
  trainCount: number;
  testCount: number;
  categories: string[];
  seasons: string[];
  historicalAverageDailySales: number;
  trainedAt: string;
  predict: (input: PredictionInput, modelType?: 'linearRegression' | 'randomForest') => {
    predictedSales: number;
    lowerEstimate: number;
    upperEstimate: number;
    margin: number;
    modelUsed: string;
  };
}

export interface PredictionInput {
  date: string;
  product_category: string;
  quantity: number;
  price: number;
  previous_sales: number;
  customers: number;
  promotion: boolean;
  holiday: boolean;
  season: string;
}

export interface PredictionResult {
  predictedSales: number;
  lowerEstimate: number;
  upperEstimate: number;
  margin: number;
  predictionDate: string;
  modelUsed: string;
  modelType: 'linearRegression' | 'randomForest';
  interpretation: 'above' | 'around' | 'below';
  historicalAverage: number;
  diffPercent: number;
  input: PredictionInput;
}

export interface ForecastDayResult {
  step: number;
  date: string;
  predictedSales: number;
  lowerEstimate: number;
  upperEstimate: number;
  dayOfWeek: string;
  isWeekend: boolean;
  product_category: string;
  season: string;
  promotion: boolean;
  holiday: boolean;
}

export interface DatasetStatistics {
  totalRecords: number;
  totalSales: number;
  averageDailySales: number;
  highestDailySales: number;
  lowestDailySales: number;
  highestSalesDate: string;
  lowestSalesDate: string;
  averageQuantity: number;
  averagePrice: number;
  totalCustomers: number;
  averageCustomers: number;
  promotionDays: number;
  promotionPercent: number;
  holidayDays: number;
  holidayPercent: number;
  dateRange: { start: string; end: string };
  categories: string[];
  seasons: string[];
}
