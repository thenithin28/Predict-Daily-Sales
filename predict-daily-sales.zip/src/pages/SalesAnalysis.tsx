import React, { useState, useMemo } from 'react';
import {
  CleanSalesRecord,
  DatasetStatistics,
} from '../types';
import { ChartCard } from '../components/ChartCard';
import { SalesTable } from '../components/SalesTable';
import {
  computeDailySalesTrend,
  computeMonthlySalesTrend,
  computeCategoryAnalysis,
  computePromotionAnalysis,
  computeHolidayAnalysis,
  computeSeasonAnalysis,
  computeWeekdayAnalysis,
  sampleScatterData,
} from '../utils/salesAnalysis';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  ScatterChart,
  Scatter,
} from 'recharts';
import { Calendar, Tag, BarChart2, TrendingUp, Layers, Users, ShoppingBag } from 'lucide-react';

interface SalesAnalysisProps {
  stats: DatasetStatistics;
  records: CleanSalesRecord[];
}

export const SalesAnalysis: React.FC<SalesAnalysisProps> = ({
  stats,
  records,
}) => {
  const [trendRange, setTrendRange] = useState<'7d' | '30d' | '90d' | '1y' | 'all'>('90d');

  const dailyTrend = useMemo(() => computeDailySalesTrend(records, trendRange), [records, trendRange]);
  const monthlyTrend = useMemo(() => computeMonthlySalesTrend(records), [records]);
  const categoryAnalysis = useMemo(() => computeCategoryAnalysis(records), [records]);
  const promoAnalysis = useMemo(() => computePromotionAnalysis(records), [records]);
  const holidayAnalysis = useMemo(() => computeHolidayAnalysis(records), [records]);
  const seasonAnalysis = useMemo(() => computeSeasonAnalysis(records), [records]);
  const weekdayAnalysis = useMemo(() => computeWeekdayAnalysis(records), [records]);
  const scatterSamples = useMemo(() => sampleScatterData(records, 150), [records]);

  const CATEGORY_COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899', '#06b6d4'];

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Daily Sales Trend Analysis (PRD Section 31) */}
      <ChartCard
        id="chart-analysis-daily-trend"
        title="Daily Sales Trend & Volume History"
        subtitle={`Displaying ${dailyTrend.length} chronological observations with moving 7-day baseline`}
        actions={
          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs">
            {(['7d', '30d', '90d', '1y', 'all'] as const).map(range => (
              <button
                key={range}
                onClick={() => setTrendRange(range)}
                className={`px-2 py-1 rounded font-medium transition-colors ${
                  trendRange === range
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {range.toUpperCase()}
              </button>
            ))}
          </div>
        }
      >
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={dailyTrend} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10.5, fill: '#64748b' }} tickLine={false} />
            <YAxis
              tick={{ fontSize: 10.5, fill: '#64748b' }}
              tickLine={false}
              tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const row = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg space-y-1">
                      <div className="font-semibold text-slate-300">{label} ({row.category})</div>
                      <div className="text-emerald-400 font-bold">Sales: {formatCurrency(row.sales)}</div>
                      {row.movingAverage7d && (
                        <div className="text-blue-400">7-Day MA: {formatCurrency(row.movingAverage7d)}</div>
                      )}
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend verticalAlign="top" align="right" wrapperStyle={{ fontSize: '11px', paddingBottom: '6px' }} />
            <Line
              type="monotone"
              dataKey="sales"
              name="Recorded Daily Sales"
              stroke="#10b981"
              strokeWidth={1.8}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="movingAverage7d"
              name="7-Day Moving Average"
              stroke="#3b82f6"
              strokeWidth={2}
              strokeDasharray="4 4"
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* 2. Monthly Trend & Day of Week Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Sales Analysis (PRD Section 32) */}
        <ChartCard
          id="chart-analysis-monthly"
          title="Monthly Sales Aggregation & MoM Velocity"
          subtitle="Total volume grouped by month with month-over-month percentage delta"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={monthlyTrend} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="monthLabel" tick={{ fontSize: 10.5, fill: '#64748b' }} tickLine={false} />
              <YAxis
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg space-y-1">
                        <div className="font-bold text-white">{label}</div>
                        <div className="text-emerald-400 font-bold">Total Sales: {formatCurrency(row.totalSales)}</div>
                        <div className="text-slate-300">Daily Average: {formatCurrency(row.averageDailySales)}</div>
                        {row.momGrowthPercent !== null && (
                          <div className={row.momGrowthPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                            MoM Delta: {row.momGrowthPercent >= 0 ? '+' : ''}{row.momGrowthPercent}%
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="totalSales" name="Total Monthly Sales" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Day-of-Week Analysis (PRD Section 39) */}
        <ChartCard
          id="chart-analysis-weekday"
          title="Day-of-Week Sales Performance"
          subtitle="Average daily volume by day of week (Monday through Sunday)"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={weekdayAnalysis} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="dayName" tick={{ fontSize: 10.5, fill: '#64748b' }} tickLine={false} />
              <YAxis
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg space-y-1">
                        <div className="font-bold text-white">{label}</div>
                        <div className="text-emerald-400 font-bold">Avg Sales: {formatCurrency(row.averageSales)}</div>
                        <div className="text-slate-300">Total Volume: {formatCurrency(row.totalSales)}</div>
                        <div className="text-slate-300">Avg Units Sold: {formatNumber(row.averageQuantity)} units</div>
                        <div className="text-slate-400">Total Observations: {row.recordCount} days</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="averageSales" name="Average Sales" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* 3. Product Category Analysis & Table (PRD Section 33) */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs p-5">
        <div className="mb-4">
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">
            Product Category Breakdown
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Total sales, daily averages, quantity metrics, and catalog price benchmarks
          </p>
        </div>

        <div className="overflow-x-auto min-w-0">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4 text-right">Total Revenue</th>
                <th className="py-2.5 px-4 text-right">Revenue Share</th>
                <th className="py-2.5 px-4 text-right">Avg Daily Sales</th>
                <th className="py-2.5 px-4 text-right">Avg Quantity</th>
                <th className="py-2.5 px-4 text-right">Avg Price</th>
                <th className="py-2.5 px-4 text-right">Total Records</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {categoryAnalysis.map((cat, idx) => (
                <tr key={cat.category} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-2.5 px-4 font-semibold text-slate-900 flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length] }}
                    />
                    <span>{cat.category}</span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-bold text-slate-900">
                    {formatCurrency(cat.totalSales)}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono">
                    {cat.salesSharePercent}%
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono">
                    {formatCurrency(cat.averageSales)}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    {formatNumber(cat.averageQuantity)} units
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    {formatCurrency(cat.averagePrice)}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-500">
                    {cat.recordCount} days
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Price vs Sales and Quantity vs Sales Scatter Analysis (PRD Section 34 & 35) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          id="chart-analysis-price-vs-sales"
          title="Price vs Daily Sales Relationship"
          subtitle="Observed unit prices against recorded daily sales revenue"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="price"
                name="Price"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${val}`}
                label={{ value: 'Unit Price ($)', position: 'insideBottom', offset: -10, fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="sales"
                name="Sales"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const p = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2 rounded-lg text-xs shadow">
                        <div className="font-bold text-slate-200">{p.category}</div>
                        <div>Price: {formatCurrency(p.price)}</div>
                        <div className="text-emerald-400 font-bold">Sales: {formatCurrency(p.sales)}</div>
                        <div className="text-slate-400">Qty: {formatNumber(p.quantity)} units</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Price Scatter" data={scatterSamples.pricePoints} fill="#f59e0b" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          id="chart-analysis-customer-vs-sales"
          title="Customer Footfall vs Sales Volume"
          subtitle="Store visitor count against daily sales across transaction records"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="customers"
                name="Customers"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                label={{ value: 'Customers Count', position: 'insideBottom', offset: -10, fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="sales"
                name="Sales"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const p = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2 rounded-lg text-xs shadow">
                        <div className="font-bold text-slate-200">{p.date} ({p.category})</div>
                        <div>Customers: {formatNumber(p.customers)}</div>
                        <div className="text-blue-400 font-bold">Sales: {formatCurrency(p.sales)}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Customer Scatter" data={scatterSamples.customerPoints} fill="#3b82f6" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* 5. Interactive Sales Explorer Table (PRD Section 29 & 30) */}
      <SalesTable
        records={records}
        categories={stats.categories}
        seasons={stats.seasons}
      />
    </div>
  );
};
