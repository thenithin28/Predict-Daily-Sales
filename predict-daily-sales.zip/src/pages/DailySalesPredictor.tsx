import React, { useState } from 'react';
import {
  TrainedModelSystem,
  CleanSalesRecord,
  DatasetStatistics,
  PredictionInput,
  PredictionResult,
  ForecastDayResult,
} from '../types';
import { SalesPredictionForm } from '../components/SalesPredictionForm';
import { PredictionResultCard } from '../components/PredictionResultCard';
import { ForecastTable } from '../components/ForecastTable';
import { ForecastChart } from '../components/ForecastChart';
import { ChartCard } from '../components/ChartCard';
import { runPrediction } from '../utils/predictionUtils';
import { generateMultiDayForecast } from '../utils/forecastUtils';
import { Sparkles, Calendar, TrendingUp } from 'lucide-react';

interface DailySalesPredictorProps {
  stats: DatasetStatistics;
  records: CleanSalesRecord[];
  modelSystem: TrainedModelSystem;
  activePrediction: PredictionResult | null;
  onSetPrediction: (res: PredictionResult) => void;
  activeForecast: ForecastDayResult[] | null;
  onSetForecast: (f: ForecastDayResult[]) => void;
}

export const DailySalesPredictor: React.FC<DailySalesPredictorProps> = ({
  stats,
  records,
  modelSystem,
  activePrediction,
  onSetPrediction,
  activeForecast,
  onSetForecast,
}) => {
  const [isPredicting, setIsPredicting] = useState(false);

  // Default last observed sales from dataset
  const lastRecord = records.length > 0 ? records[records.length - 1] : null;
  const lastSales = lastRecord ? lastRecord.sales : 5000;
  const lastDate = lastRecord ? lastRecord.date : '2025-08-31';

  const handlePredict = (
    input: PredictionInput,
    horizon: number,
    modelChoice: 'linearRegression' | 'randomForest' | 'auto'
  ) => {
    setIsPredicting(true);

    try {
      const chosenModelType = modelChoice === 'auto' ? modelSystem.bestModelType : modelChoice;
      // 1. Single day prediction
      const singleResult = runPrediction(input, modelSystem, chosenModelType);
      onSetPrediction(singleResult);

      // 2. Multi-day forecast schedule
      const forecastDays = generateMultiDayForecast(input, horizon, modelSystem, chosenModelType);
      onSetForecast(forecastDays);
    } catch (err) {
      console.error('Prediction failed:', err);
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Configuration & Input Form */}
      <SalesPredictionForm
        categories={stats.categories}
        seasons={stats.seasons}
        lastObservedSales={lastSales}
        lastDateStr={lastDate}
        modelSystem={modelSystem}
        onPredict={handlePredict}
        isPredicting={isPredicting}
      />

      {/* Prominent Prediction Result Card (PRD Section 23, 24, 25, 55) */}
      {activePrediction && (
        <div className="grid grid-cols-1 gap-6">
          <PredictionResultCard result={activePrediction} />
        </div>
      )}

      {/* Forecast Timeline Chart (PRD Section 27) */}
      {activeForecast && activeForecast.length > 0 && (
        <ChartCard
          id="chart-forecast-timeline"
          title="Sales Forecast Timeline & Confidence Interval"
          subtitle="Seamless bridge from historical observations into the forward projection window"
        >
          <ForecastChart
            historicalRecords={records}
            forecasts={activeForecast}
          />
        </ChartCard>
      )}

      {/* Multi-Day Forecast Table (PRD Section 26) */}
      {activeForecast && activeForecast.length > 0 && (
        <ForecastTable forecasts={activeForecast} />
      )}
    </div>
  );
};
