import React, { useState, useMemo } from 'react';
import {
  FileText,
  DollarSign,
  TrendingUp,
  Package,
  Users,
  Calendar,
  Sparkles,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  Sun,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  ScatterChart,
  Scatter,
} from 'recharts';
import {
  CleanSalesRecord,
  DatasetStatistics,
  TrainedModelSystem,
  PredictionResult,
} from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import { DynamicInsightsCard } from '../components/DynamicInsightsCard';
import {
  computeDailySalesTrend,
  computeMonthlySalesTrend,
  computeCategoryAnalysis,
  computePromotionAnalysis,
  computeHolidayAnalysis,
  computeSeasonAnalysis,
  sampleScatterData,
} from '../utils/salesAnalysis';
import { generateDynamicInsights } from '../utils/insights';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';

interface DashboardProps {
  stats: DatasetStatistics;
  records: CleanSalesRecord[];
  modelSystem: TrainedModelSystem;
  onNavigateToPredictor: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  stats,
  records,
  modelSystem,
  onNavigateToPredictor,
}) => {
  const [dailyRange, setDailyRange] = useState<'7d' | '30d' | '90d' | '1y' | 'all'>('30d');

  // Derived datasets
  const dailyTrend = useMemo(() => computeDailySalesTrend(records, dailyRange), [records, dailyRange]);
  const monthlyTrend = useMemo(() => computeMonthlySalesTrend(records), [records]);
  const categoryAnalysis = useMemo(() => computeCategoryAnalysis(records), [records]);
  const promoAnalysis = useMemo(() => computePromotionAnalysis(records), [records]);
  const holidayAnalysis = useMemo(() => computeHolidayAnalysis(records), [records]);
  const seasonAnalysis = useMemo(() => computeSeasonAnalysis(records), [records]);
  const scatterSamples = useMemo(() => sampleScatterData(records, 100), [records]);
  const insights = useMemo(() => generateDynamicInsights(stats, modelSystem, records), [stats, modelSystem, records]);

  const CATEGORY_COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899', '#06b6d4'];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner with Dataset Summary and Quick Action */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 sm:p-7 border border-slate-700/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            Machine Learning Production Dashboard
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Daily Business Sales Intelligence &amp; Forecasting
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Historical dataset spanning {stats.dateRange.start} through {stats.dateRange.end} with {formatNumber(stats.totalRecords)} cleaned daily observations, dynamic lag engineering, and continuous dual-model evaluation.
          </p>
        </div>

        <button
          id="btn-goto-predictor"
          onClick={onNavigateToPredictor}
          className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
        >
          <TrendingUp className="w-4 h-4" />
          <span>Launch Sales Predictor</span>
        </button>
      </div>

      {/* 10 Required KPI Stat Cards (PRD Section 5) */}
      <div>
        <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 px-1">
          Historical Business Vital Statistics (Calculated Live)
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          <StatCard
            id="kpi-total-records"
            title="Total Sales Records"
            value={formatNumber(stats.totalRecords)}
            subtitle={`${stats.dateRange.start} to ${stats.dateRange.end}`}
            icon={FileText}
            badge="100% Valid"
            badgeColor="slate"
          />

          <StatCard
            id="kpi-total-sales"
            title="Total Sales Revenue"
            value={formatCurrency(stats.totalSales)}
            subtitle="Cumulative business volume"
            icon={DollarSign}
            badge="Verified"
            badgeColor="emerald"
          />

          <StatCard
            id="kpi-avg-daily-sales"
            title="Average Daily Sales"
            value={formatCurrency(stats.averageDailySales)}
            subtitle="Historical baseline expectation"
            icon={TrendingUp}
            badge="Baseline"
            badgeColor="blue"
          />

          <StatCard
            id="kpi-highest-sales"
            title="Highest Daily Sales"
            value={formatCurrency(stats.highestDailySales)}
            subtitle={`Peak on ${stats.highestSalesDate}`}
            icon={ArrowUpRight}
            badge="Peak Record"
            badgeColor="purple"
          />

          <StatCard
            id="kpi-lowest-sales"
            title="Lowest Daily Sales"
            value={formatCurrency(stats.lowestDailySales)}
            subtitle={`Floor on ${stats.lowestSalesDate}`}
            icon={ArrowDownRight}
            badge="Trough"
            badgeColor="slate"
          />

          <StatCard
            id="kpi-avg-quantity"
            title="Average Quantity Sold"
            value={`${formatNumber(stats.averageQuantity)} units`}
            subtitle="Per daily business cycle"
            icon={Package}
            badge="Inventory"
            badgeColor="slate"
          />

          <StatCard
            id="kpi-avg-price"
            title="Average Unit Price"
            value={formatCurrency(stats.averagePrice)}
            subtitle="Weighted catalog pricing"
            icon={DollarSign}
            badge="Catalog"
            badgeColor="slate"
          />

          <StatCard
            id="kpi-total-customers"
            title="Total Customer Footfall"
            value={formatNumber(stats.totalCustomers)}
            subtitle={`~${formatNumber(stats.averageCustomers)} / day`}
            icon={Users}
            badge="Engagement"
            badgeColor="blue"
          />

          <StatCard
            id="kpi-promotion-days"
            title="Promotion Days"
            value={`${stats.promotionDays} days`}
            subtitle={`${stats.promotionPercent}% of total trading days`}
            icon={Award}
            badge="Marketing"
            badgeColor="amber"
          />

          <StatCard
            id="kpi-holiday-days"
            title="Holiday Days"
            value={`${stats.holidayDays} days`}
            subtitle={`${stats.holidayPercent}% of total trading days`}
            icon={Calendar}
            badge="Calendar"
            badgeColor="purple"
          />
        </div>
      </div>

      {/* Primary Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Daily Sales Trend */}
        <ChartCard
          id="chart-daily-sales-trend"
          title="Daily Sales Trend & Moving Average"
          subtitle="Observed daily transactions with rolling 7-day smoothing"
          actions={
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs">
              {(['7d', '30d', '90d', '1y', 'all'] as const).map(range => (
                <button
                  key={range}
                  onClick={() => setDailyRange(range)}
                  className={`px-2 py-1 rounded font-medium transition-colors ${
                    dailyRange === range
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {range.toUpperCase()}
                </button>
              ))}
            </div>
          }
        >
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={dailyTrend} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg space-y-1">
                        <div className="font-semibold text-slate-300">{label} ({row.category})</div>
                        <div className="text-emerald-400 font-bold">
                          Daily Sales: {formatCurrency(row.sales)}
                        </div>
                        {row.movingAverage7d && (
                          <div className="text-blue-400">
                            7-Day Avg: {formatCurrency(row.movingAverage7d)}
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ fontSize: '11px', paddingBottom: '6px' }} />
              <Line
                type="monotone"
                dataKey="sales"
                name="Daily Sales"
                stroke="#10b981"
                strokeWidth={1.8}
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="movingAverage7d"
                name="7-Day Moving Avg"
                stroke="#3b82f6"
                strokeWidth={2}
                strokeDasharray="3 3"
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 2: Monthly Sales Trend */}
        <ChartCard
          id="chart-monthly-sales-trend"
          title="Monthly Aggregated Sales Trend"
          subtitle="Total volume grouped by calendar month with average daily run-rate"
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthlyTrend} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="monthLabel" tick={{ fontSize: 10.5, fill: '#64748b' }} tickLine={false} />
              <YAxis
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg space-y-1">
                        <div className="font-semibold text-slate-300">{label} ({row.recordCount} Days)</div>
                        <div className="text-emerald-400 font-bold">Total Sales: {formatCurrency(row.totalSales)}</div>
                        <div className="text-slate-300">Daily Average: {formatCurrency(row.averageDailySales)}</div>
                        {row.momGrowthPercent !== null && (
                          <div className={row.momGrowthPercent >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                            MoM Change: {row.momGrowthPercent >= 0 ? '+' : ''}{row.momGrowthPercent}%
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ fontSize: '11px', paddingBottom: '6px' }} />
              <Bar dataKey="totalSales" name="Monthly Total Sales" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 3: Sales by Product Category */}
        <ChartCard
          id="chart-category-sales"
          title="Sales by Product Category"
          subtitle="Total revenue distribution across all registered product departments"
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart
              layout="vertical"
              data={categoryAnalysis}
              margin={{ top: 10, right: 20, bottom: 5, left: 95 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
              <XAxis
                type="number"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <YAxis
                type="category"
                dataKey="category"
                tick={{ fontSize: 11, fill: '#334155' }}
                tickLine={false}
                width={90}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow space-y-1">
                        <div className="font-bold text-white">{row.category}</div>
                        <div className="text-emerald-400 font-bold">Total Sales: {formatCurrency(row.totalSales)} ({row.salesSharePercent}%)</div>
                        <div className="text-slate-300">Avg Daily Sales: {formatCurrency(row.averageSales)}</div>
                        <div className="text-slate-300">Avg Unit Price: {formatCurrency(row.averagePrice)}</div>
                        <div className="text-slate-400">Total Observations: {row.recordCount} days</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="totalSales" name="Category Total Sales" radius={[0, 4, 4, 0]}>
                {categoryAnalysis.map((_, idx) => (
                  <Cell key={idx} fill={CATEGORY_COLORS[idx % CATEGORY_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 4: Promotion vs Sales */}
        <ChartCard
          id="chart-promotion-sales"
          title="Promotion vs Non-Promotion Sales Performance"
          subtitle={`Observed revenue lift of ${promoAnalysis.upliftPercent >= 0 ? '+' : ''}${promoAnalysis.upliftPercent}% on active promotional days`}
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {promoAnalysis.groups.map(g => (
                <div key={g.flag} className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                  <span className="text-slate-500 font-medium block">{g.flag}</span>
                  <div className="text-lg font-bold text-slate-900 mt-0.5">
                    {formatCurrency(g.averageSales)} <span className="text-[11px] font-normal text-slate-500">avg/day</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {formatNumber(g.count)} days ({formatNumber(g.averageQuantity)} units/day)
                  </div>
                </div>
              ))}
            </div>

            <ResponsiveContainer width="100%" height={170}>
              <BarChart data={promoAnalysis.groups} margin={{ top: 5, right: 10, bottom: 5, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="flag" tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 10.5, fill: '#64748b' }}
                  tickLine={false}
                  tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(Number(val)), 'Average Sales']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="averageSales" name="Average Sales" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 5: Holiday vs Sales */}
        <ChartCard
          id="chart-holiday-sales"
          title="Holiday vs Regular Operations"
          subtitle={`Calendar holiday performance comparison (${holidayAnalysis.upliftPercent >= 0 ? '+' : ''}${holidayAnalysis.upliftPercent}% difference)`}
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {holidayAnalysis.groups.map(g => (
                <div key={g.flag} className="p-3 rounded-lg bg-slate-50 border border-slate-200/70">
                  <span className="text-slate-500 font-medium block">{g.flag}</span>
                  <div className="text-lg font-bold text-slate-900 mt-0.5">
                    {formatCurrency(g.averageSales)} <span className="text-[11px] font-normal text-slate-500">avg/day</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {formatNumber(g.count)} total days observed
                  </div>
                </div>
              ))}
            </div>

            <ResponsiveContainer width="100%" height={170}>
              <BarChart data={holidayAnalysis.groups} margin={{ top: 5, right: 10, bottom: 5, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="flag" tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 10.5, fill: '#64748b' }}
                  tickLine={false}
                  tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(Number(val)), 'Average Sales']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="averageSales" name="Average Sales" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 6: Seasonal Sales */}
        <ChartCard
          id="chart-seasonal-sales"
          title="Seasonal Sales Distribution"
          subtitle="Performance across Fall, Winter, Spring, and Summer periods"
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={seasonAnalysis} margin={{ top: 10, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="season" tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} />
              <YAxis
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const row = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow space-y-1">
                        <div className="font-bold text-white">{label} Season ({row.recordCount} Days)</div>
                        <div className="text-amber-400 font-bold">Total Sales: {formatCurrency(row.totalSales)}</div>
                        <div className="text-slate-300">Average Daily Sales: {formatCurrency(row.averageSales)}</div>
                        <div className="text-slate-300">Average Units Sold: {formatNumber(row.averageQuantity)} / day</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="totalSales" name="Total Sales" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 7: Quantity vs Sales */}
        <ChartCard
          id="chart-quantity-vs-sales"
          title="Quantity Sold vs Daily Sales"
          subtitle="Observed volume correlation across transaction records"
        >
          <ResponsiveContainer width="100%" height={280}>
            <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="quantity"
                name="Quantity"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                label={{ value: 'Units Sold', position: 'insideBottom', offset: -10, fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="sales"
                name="Sales"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const p = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2 rounded-lg text-xs shadow">
                        <div className="font-bold text-slate-200">{p.category}</div>
                        <div>Quantity: {formatNumber(p.quantity)} units</div>
                        <div className="text-emerald-400 font-bold">Sales: {formatCurrency(p.sales)}</div>
                        <div className="text-slate-400">Unit Price: {formatCurrency(p.price)}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Transactions" data={scatterSamples.quantityPoints} fill="#10b981" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 8: Customer Count vs Sales */}
        <ChartCard
          id="chart-customers-vs-sales"
          title="Customer Footfall vs Daily Sales"
          subtitle="Relationship between daily store customers and total recorded revenue"
        >
          <ResponsiveContainer width="100%" height={280}>
            <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="customers"
                name="Customers"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                label={{ value: 'Customer Footfall', position: 'insideBottom', offset: -10, fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="sales"
                name="Sales"
                tick={{ fontSize: 10.5, fill: '#64748b' }}
                tickLine={false}
                tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const p = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2 rounded-lg text-xs shadow">
                        <div className="font-bold text-slate-200">{p.date} ({p.category})</div>
                        <div>Footfall: {formatNumber(p.customers)} visitors</div>
                        <div className="text-blue-400 font-bold">Sales: {formatCurrency(p.sales)}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Customer Traffic" data={scatterSamples.customerPoints} fill="#3b82f6" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Dynamic Insights at the bottom of Dashboard (PRD Section 49) */}
      <DynamicInsightsCard insights={insights} />
    </div>
  );
};
