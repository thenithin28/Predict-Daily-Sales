import React, { useState } from 'react';
import {
  TrainedModelSystem,
  DatasetStatistics,
} from '../types';
import { ModelMetricsCard } from '../components/ModelMetricsCard';
import { ActualVsPredictedChart } from '../components/ActualVsPredictedChart';
import { ResidualChart } from '../components/ResidualChart';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import { ChartCard } from '../components/ChartCard';
import { StatCard } from '../components/StatCard';
import { formatCurrency, formatNumber } from '../utils/predictionUtils';
import { BrainCircuit, Cpu, Trophy, Target, TrendingUp, CheckCircle2 } from 'lucide-react';

interface ModelPerformanceProps {
  modelSystem: TrainedModelSystem;
  stats: DatasetStatistics;
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({
  modelSystem,
  stats,
}) => {
  const [activeModelTab, setActiveModelTab] = useState<'selected' | 'rf' | 'lr'>('selected');

  const lr = modelSystem.linearRegression;
  const rf = modelSystem.randomForest;
  const isRfBest = modelSystem.bestModelType === 'randomForest';

  const displayedMetrics =
    activeModelTab === 'lr'
      ? lr
      : activeModelTab === 'rf'
      ? rf
      : isRfBest
      ? rf
      : lr;

  return (
    <div className="space-y-6 pb-12">
      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard
          id="stat-eval-split"
          title="Evaluation Split"
          value={`${modelSystem.trainCount} / ${modelSystem.testCount}`}
          subtitle="80% Train / 20% Test (Chronological)"
          icon={BrainCircuit}
          badge="No Leakage"
          badgeColor="emerald"
        />

        <StatCard
          id="stat-best-rmse"
          title="Optimal Out-of-Sample RMSE"
          value={formatCurrency(displayedMetrics.rmse)}
          subtitle={`Achieved by ${displayedMetrics.name}`}
          icon={Target}
          badge="Test Error"
          badgeColor="purple"
        />

        <StatCard
          id="stat-best-r2"
          title="R² Coefficient of Determination"
          value={displayedMetrics.r2.toFixed(4)}
          subtitle="Proportion of variance explained"
          icon={Trophy}
          badge={`${(displayedMetrics.r2 * 100).toFixed(1)}%`}
          badgeColor="blue"
        />

        <StatCard
          id="stat-best-mae"
          title="Mean Absolute Error (MAE)"
          value={formatCurrency(displayedMetrics.mae)}
          subtitle="Average dollar test divergence"
          icon={TrendingUp}
          badge="Out-of-Sample"
          badgeColor="slate"
        />
      </div>

      {/* Model Benchmark Table (PRD Section 42 & 45) */}
      <ModelMetricsCard
        linearMetrics={lr}
        rfMetrics={rf}
        bestModelType={modelSystem.bestModelType}
      />

      {/* Interactive Model Toggle for Charts */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-600" />
            Diagnostic Visualizations for Active Model
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Switch model to inspect residuals, prediction distributions, and feature importance
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs self-start sm:self-auto">
          <button
            onClick={() => setActiveModelTab('selected')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeModelTab === 'selected'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Auto Selection ({isRfBest ? 'Random Forest' : 'Linear Reg.'})
          </button>
          <button
            onClick={() => setActiveModelTab('rf')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeModelTab === 'rf'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
          <button
            onClick={() => setActiveModelTab('lr')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeModelTab === 'lr'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Regression
          </button>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Actual vs Predicted Scatter (PRD Section 43) */}
        <ChartCard
          id="chart-actual-vs-predicted"
          title={`Actual vs Predicted Sales (${displayedMetrics.name})`}
          subtitle="Test-set observations compared against the ideal fit reference line (y = x)"
        >
          <ActualVsPredictedChart
            predictions={displayedMetrics.predictions}
            modelName={displayedMetrics.name}
          />
        </ChartCard>

        {/* Residual Analysis (PRD Section 44) */}
        <ChartCard
          id="chart-residual-analysis"
          title={`Residual Analysis (${displayedMetrics.name})`}
          subtitle="Evaluating error distribution and heteroscedasticity across predicted values"
        >
          <ResidualChart
            predictions={displayedMetrics.predictions}
            meanResidual={displayedMetrics.meanResidual}
            maxPositiveResidual={displayedMetrics.maxPositiveResidual}
            maxNegativeResidual={displayedMetrics.maxNegativeResidual}
          />
        </ChartCard>
      </div>

      {/* Feature Importance Analysis (PRD Section 46) */}
      <ChartCard
        id="chart-feature-importance"
        title={`Calculated Feature Importance Ranking (${displayedMetrics.name})`}
        subtitle="Relative contribution of engineered historical, temporal, and business factors to prediction variance reduction"
      >
        <FeatureImportanceChart
          importances={displayedMetrics.featureImportance}
          modelName={displayedMetrics.name}
        />
      </ChartCard>
    </div>
  );
};
