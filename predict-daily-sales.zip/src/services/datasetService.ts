import Papa from 'papaparse';
import { RawSalesRecord, CleanSalesRecord, DatasetStatistics } from '../types';
import { cleanAndPreprocessSales } from '../ml/preprocessing';

export async function loadDefaultDataset(): Promise<{
  raw: RawSalesRecord[];
  cleaned: CleanSalesRecord[];
  stats: DatasetStatistics;
}> {
  const response = await fetch('/data/daily_sales.csv');
  if (!response.ok) {
    throw new Error(`Failed to load sales dataset: HTTP ${response.status}`);
  }
  const csvText = await response.text();
  return parseSalesCsvText(csvText);
}

export function parseSalesCsvText(csvText: string): {
  raw: RawSalesRecord[];
  cleaned: CleanSalesRecord[];
  stats: DatasetStatistics;
} {
  const parseResult = Papa.parse<RawSalesRecord>(csvText, {
    header: true,
    skipEmptyLines: true,
  });

  if (parseResult.errors && parseResult.errors.length > 0) {
    console.warn('CSV parsing notices:', parseResult.errors.slice(0, 5));
  }

  const rawRows = parseResult.data;
  if (!rawRows || rawRows.length === 0) {
    throw new Error('The provided CSV file contains no data rows.');
  }

  // Validate that required fields exist or can be derived
  const firstRow = rawRows[0];
  const keys = Object.keys(firstRow).map(k => k.toLowerCase().trim());

  if (!keys.includes('date') || !keys.includes('sales')) {
    throw new Error('CSV must contain at least "date" and "sales" columns.');
  }

  const cleaned = cleanAndPreprocessSales(rawRows);
  if (cleaned.length === 0) {
    throw new Error('No valid daily sales records were found after data cleaning.');
  }

  const stats = calculateDatasetStatistics(cleaned);

  return {
    raw: rawRows,
    cleaned,
    stats,
  };
}

export function calculateDatasetStatistics(records: CleanSalesRecord[]): DatasetStatistics {
  const totalRecords = records.length;
  if (totalRecords === 0) {
    return {
      totalRecords: 0,
      totalSales: 0,
      averageDailySales: 0,
      highestDailySales: 0,
      lowestDailySales: 0,
      highestSalesDate: 'N/A',
      lowestSalesDate: 'N/A',
      averageQuantity: 0,
      averagePrice: 0,
      totalCustomers: 0,
      averageCustomers: 0,
      promotionDays: 0,
      promotionPercent: 0,
      holidayDays: 0,
      holidayPercent: 0,
      dateRange: { start: '', end: '' },
      categories: [],
      seasons: [],
    };
  }

  let totalSales = 0;
  let totalQty = 0;
  let totalPrice = 0;
  let totalCustomers = 0;
  let promotionDays = 0;
  let holidayDays = 0;

  let highestSales = -Infinity;
  let highestDate = '';
  let lowestSales = Infinity;
  let lowestDate = '';

  const catSet = new Set<string>();
  const seasonSet = new Set<string>();

  for (const r of records) {
    totalSales += r.sales;
    totalQty += r.quantity;
    totalPrice += r.price;
    totalCustomers += r.customers;
    if (r.promotion) promotionDays++;
    if (r.holiday) holidayDays++;

    if (r.sales > highestSales) {
      highestSales = r.sales;
      highestDate = r.date;
    }
    if (r.sales < lowestSales) {
      lowestSales = r.sales;
      lowestDate = r.date;
    }

    if (r.product_category) catSet.add(r.product_category);
    if (r.season) seasonSet.add(r.season);
  }

  const averageDailySales = Math.round(totalSales / totalRecords);
  const averageQuantity = Math.round(totalQty / totalRecords);
  const averagePrice = Number((totalPrice / totalRecords).toFixed(2));
  const averageCustomers = Math.round(totalCustomers / totalRecords);
  const promotionPercent = Number(((promotionDays / totalRecords) * 100).toFixed(1));
  const holidayPercent = Number(((holidayDays / totalRecords) * 100).toFixed(1));

  return {
    totalRecords,
    totalSales: Math.round(totalSales),
    averageDailySales,
    highestDailySales: Math.round(highestSales),
    lowestDailySales: Math.round(lowestSales),
    highestSalesDate: highestDate,
    lowestSalesDate: lowestDate,
    averageQuantity,
    averagePrice,
    totalCustomers,
    averageCustomers,
    promotionDays,
    promotionPercent,
    holidayDays,
    holidayPercent,
    dateRange: {
      start: records[0].date,
      end: records[records.length - 1].date,
    },
    categories: Array.from(catSet).sort(),
    seasons: Array.from(seasonSet).sort(),
  };
}
